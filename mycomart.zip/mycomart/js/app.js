// ============================================================
//  MYCOMART — JavaScript Core
//  Brand name chosen: MycōMart (from 10 ideas below)
// ============================================================
//
//  Brand Name Ideas (10):
//  1. MycōMart      — Myco (fungus) + Mart (market). Short, modern, memorable ✅ CHOSEN
//  2. Shroomly      — Friendly, youthful, mushroom-inspired
//  3. FungiFarm     — Direct, clear, farmstead feel
//  4. EarthCap      — Cap (mushroom cap) + Earth = organic nature
//  5. SporeBox      — Subscription box feel, modern
//  6. MossGrove     — Evokes nature, forest, tranquility
//  7. HarvestHub    — Harvest + marketplace hub
//  8. CanopyCo      — Forest canopy, premium co-brand
//  9. NaturCap      — Natural + Mushroom cap, clean
//  10. MyceliaFresh — Mycelium + Fresh = scientific + organic
//
// ============================================================

'use strict';

// ─── GLOBAL STATE ──────────────────────────────────────────
const state = {
  cart: JSON.parse(localStorage.getItem('mycomart_cart') || '[]'),
  wishlist: JSON.parse(localStorage.getItem('mycomart_wishlist') || '[]'),
  theme: localStorage.getItem('mycomart_theme') || 'light',
  currentPage: 'home'
};

// ─── PRODUCT DATA ──────────────────────────────────────────
const products = [
  {
    id: 1,
    name: 'Creamy White Button Mushroom',
    category: 'button',
    categoryLabel: 'Button Mushroom',
    emoji: '🍄',
    prices: { '250g': 65, '500g': 120, '1kg': 225 },
    originalPrices: { '250g': 85, '500g': 155, '1kg': 295 },
    rating: 4.8,
    reviews: 247,
    description: 'Freshly harvested from our Angul farm. Plump, firm, and loaded with umami richness — perfect for daily cooking.',
    longDesc: 'Our Button Mushrooms are grown in carefully controlled environments at our Pokatunga, Bantala farm. Harvested at peak freshness and delivered within 24 hours. Rich in B vitamins, selenium, and antioxidants.',
    nutrition: { calories: '22 kcal / 100g', protein: '3.1g', fiber: '1g', vitamin_d: '7% DV' },
    benefits: ['Boosts immunity', 'Rich in antioxidants', 'Low calorie', 'High protein'],
    tags: ['fresh', 'bestseller', 'daily'],
    badge: 'Best Seller',
    badgeColor: 'badge-gold',
    inStock: true,
    stockQty: 120
  },
  {
    id: 2,
    name: 'Blue Oyster Mushroom',
    category: 'oyster',
    categoryLabel: 'Oyster Mushroom',
    emoji: '🫐',
    prices: { '250g': 85, '500g': 160, '1kg': 299 },
    originalPrices: { '250g': 110, '500g': 205, '1kg': 385 },
    rating: 4.9,
    reviews: 182,
    description: 'Delicate, fan-shaped blue oyster mushrooms with a velvety texture and mild, nutty flavour.',
    longDesc: 'Blue Oyster mushrooms are prized for their striking appearance and incredible nutritional profile. Grown on natural substrate at our Bantala farm, these mushrooms contain powerful anti-inflammatory compounds.',
    nutrition: { calories: '33 kcal / 100g', protein: '3.3g', fiber: '2.3g', vitamin_b: '28% DV' },
    benefits: ['Anti-inflammatory', 'Heart health', 'Brain booster', 'Immune support'],
    tags: ['fresh', 'premium', 'organic'],
    badge: 'Organic',
    badgeColor: 'badge-green',
    inStock: true,
    stockQty: 75
  },
  {
    id: 3,
    name: 'Golden Oyster Mushroom',
    category: 'oyster',
    categoryLabel: 'Oyster Mushroom',
    emoji: '🌟',
    prices: { '250g': 95, '500g': 178, '1kg': 335 },
    originalPrices: { '250g': 125, '500g': 230, '1kg': 430 },
    rating: 4.7,
    reviews: 134,
    description: 'Vibrant golden clusters with a fruity, mild aroma. Rare and exotic variety from our farm.',
    longDesc: 'Golden Oyster mushrooms are one of the most visually stunning varieties we grow. Their golden colour and delicate texture make them a favourite among chefs and health enthusiasts alike.',
    nutrition: { calories: '35 kcal / 100g', protein: '3.5g', fiber: '2.0g', vitamin_c: '12% DV' },
    benefits: ['Cholesterol reducer', 'Energy booster', 'Antioxidant rich', 'Digestive health'],
    tags: ['premium', 'rare', 'chef-favorite'],
    badge: 'Rare',
    badgeColor: 'badge-blue',
    inStock: true,
    stockQty: 40
  },
  {
    id: 4,
    name: 'Wild Shiitake Mushroom',
    category: 'shiitake',
    categoryLabel: 'Shiitake Mushroom',
    emoji: '🌰',
    prices: { '250g': 110, '500g': 210, '1kg': 399 },
    originalPrices: { '250g': 145, '500g': 270, '1kg': 510 },
    rating: 4.9,
    reviews: 319,
    description: 'Classic Shiitake with deep, smoky umami. Medicinal powerhouse from our log-grown cultivation.',
    longDesc: 'Our Shiitake mushrooms are log-grown using traditional Japanese methods adapted to Odisha\'s climate. Each mushroom is packed with lentinan, a powerful beta-glucan known for immune support.',
    nutrition: { calories: '34 kcal / 100g', protein: '2.2g', fiber: '2.5g', copper: '65% DV' },
    benefits: ['Immune booster', 'Lowers cholesterol', 'Anti-cancer', 'Liver protection'],
    tags: ['premium', 'medicinal', 'bestseller'],
    badge: 'Premium',
    badgeColor: 'badge-gold',
    inStock: true,
    stockQty: 85
  },
  {
    id: 5,
    name: 'Pink Oyster Mushroom',
    category: 'oyster',
    categoryLabel: 'Oyster Mushroom',
    emoji: '🌸',
    prices: { '250g': 90, '500g': 170, '1kg': 320 },
    originalPrices: { '250g': 115, '500g': 215, '1kg': 405 },
    rating: 4.6,
    reviews: 98,
    description: 'Striking hot-pink clusters with a succulent, meaty texture. Turns light pink when cooked.',
    longDesc: 'Pink Oyster mushrooms are a tropical variety perfectly suited to Odisha\'s warm climate. They have a distinctive seafood-like flavour when cooked and are a great meat substitute.',
    nutrition: { calories: '38 kcal / 100g', protein: '3.7g', fiber: '2.1g', iron: '8% DV' },
    benefits: ['Protein-rich', 'Meat substitute', 'Antifungal properties', 'Gut health'],
    tags: ['fresh', 'exotic', 'vegan'],
    badge: 'New',
    badgeColor: 'badge-green',
    inStock: true,
    stockQty: 55
  },
  {
    id: 6,
    name: 'Dried Shiitake Pack',
    category: 'shiitake',
    categoryLabel: 'Shiitake Mushroom',
    emoji: '🍂',
    prices: { '100g': 150, '250g': 345, '500g': 659 },
    originalPrices: { '100g': 190, '250g': 440, '500g': 840 },
    rating: 4.8,
    reviews: 205,
    description: 'Sun-dried Shiitake with 10x concentrated nutrients. Perfect for soups, broths, and long shelf life.',
    longDesc: 'Our dried Shiitake are naturally sun-dried at our Angul farm, locking in all the goodness. One 100g pack is equivalent to 1kg of fresh mushrooms in flavour and nutrition.',
    nutrition: { calories: '296 kcal / 100g', protein: '9.6g', fiber: '11.5g', vitamin_d: '45% DV' },
    benefits: ['Long shelf life', 'Concentrated nutrition', 'Intense umami', 'Travel friendly'],
    tags: ['dried', 'shelf-stable', 'value'],
    badge: '15% OFF',
    badgeColor: 'badge-red',
    inStock: true,
    stockQty: 200
  },
  {
    id: 7,
    name: 'Button Mushroom (Organic Certified)',
    category: 'button',
    categoryLabel: 'Button Mushroom',
    emoji: '✅',
    prices: { '250g': 80, '500g': 148, '1kg': 275 },
    originalPrices: { '250g': 100, '500g': 185, '1kg': 345 },
    rating: 4.7,
    reviews: 167,
    description: 'NPOP Organic certified Button Mushrooms. Grown without chemicals, verified pure from Pokatunga farm.',
    longDesc: 'These are our flagship certified organic button mushrooms, verified by NPOP (National Programme for Organic Production). Grown using only natural compost and tested free of pesticide residues.',
    nutrition: { calories: '22 kcal / 100g', protein: '3.1g', fiber: '1g', potassium: '9% DV' },
    benefits: ['Pesticide-free', 'NPOP certified', 'Naturally grown', 'Farm fresh'],
    tags: ['organic', 'certified', 'premium'],
    badge: 'Certified Organic',
    badgeColor: 'badge-green',
    inStock: true,
    stockQty: 95
  },
  {
    id: 8,
    name: 'Mixed Mushroom Combo Box',
    category: 'button',
    categoryLabel: 'Combo Pack',
    emoji: '📦',
    prices: { '500g': 199, '1kg': 375 },
    originalPrices: { '500g': 260, '1kg': 490 },
    rating: 4.9,
    reviews: 421,
    description: 'Best value combo! Button + Oyster + Shiitake. Try all three premium varieties in one box.',
    longDesc: 'Our most popular product — the MycōMart Mixed Box brings together all three of our specialty mushroom varieties. Handpicked on the same day and packed in eco-friendly packaging.',
    nutrition: { calories: '28 kcal / 100g avg', protein: '3.0g avg', fiber: '1.8g', vitamin_b12: '15% DV' },
    benefits: ['Variety pack', 'Best value', 'Farm fresh', 'Gift ready'],
    tags: ['combo', 'bestseller', 'gift'],
    badge: '🔥 Hot Deal',
    badgeColor: 'badge-red',
    inStock: true,
    stockQty: 60
  }
];

const blogPosts = [
  { id: 1, title: 'How We Built Our Mushroom Farm from Scratch in Rural Odisha', emoji: '🌱', date: 'March 5, 2025', category: 'Farm Story', excerpt: 'The journey of three brothers from Angul district who turned a small shed into a thriving mushroom enterprise...', readTime: '6 min read' },
  { id: 2, title: '5 Reasons Why Shiitake Mushrooms Are Nature\'s Best Medicine', emoji: '🍄', date: 'Feb 20, 2025', category: 'Health', excerpt: 'Modern science is catching up to what Japanese healers knew for centuries — Shiitake is a medicinal powerhouse...', readTime: '4 min read' },
  { id: 3, title: 'Mushroom Cultivation Guide for Beginners in India', emoji: '📚', date: 'Feb 10, 2025', category: 'Farming Guide', excerpt: 'Want to start growing mushrooms at home or commercially? Here is the complete step-by-step guide from our experts...', readTime: '8 min read' },
  { id: 4, title: 'Delicious Oyster Mushroom Recipes for Indian Kitchens', emoji: '🍳', date: 'Jan 25, 2025', category: 'Recipes', excerpt: 'From Oyster Mushroom curry to stir-fry and soup — 10 easy recipes that will transform your cooking...', readTime: '5 min read' },
  { id: 5, title: 'The Climate Advantage: Why Odisha is Perfect for Mushroom Farming', emoji: '🌦️', date: 'Jan 12, 2025', category: 'Science', excerpt: 'Angul district\'s unique microclimate offers ideal humidity and temperature conditions for premium mushroom growth...', readTime: '5 min read' },
  { id: 6, title: 'Organic Certification Journey: What It Took to Get NPOP Certified', emoji: '📜', date: 'Dec 28, 2024', category: 'Behind the Scenes', excerpt: 'The rigorous 18-month process we undertook to achieve organic certification for our Bantala farm...', readTime: '7 min read' }
];

const faqs = [
  { q: 'Where are your mushrooms grown?', a: 'All our mushrooms are grown at our family farm in Pokatunga, Bantala, Angul, Odisha. We maintain full farm-to-table transparency with no outsourcing.' },
  { q: 'How fresh are the mushrooms at delivery?', a: 'We harvest mushrooms the same day your order is placed (for orders before 10 AM). Same-day delivery in Angul district, and 24-48 hour delivery for other cities via our cold-chain logistics.' },
  { q: 'Are your mushrooms certified organic?', a: 'Yes! Our Button Mushroom range is NPOP (National Programme for Organic Production) certified. All our products are grown without synthetic chemicals. Certification available on request.' },
  { q: 'Do you offer bulk or wholesale pricing?', a: 'Yes, we offer special pricing for restaurants, hotels, and resellers. Contact us at wholesale@mycomart.in or call +91 94370 XXXXX for bulk orders above 10kg.' },
  { q: 'What is your return policy?', a: 'We have a 100% freshness guarantee. If you receive mushrooms that are not fresh, we will replace them the same day or issue a full refund. No questions asked.' },
  { q: 'How should I store my mushrooms?', a: 'Fresh mushrooms should be kept in the refrigerator in a paper bag (not plastic). They stay fresh for 5-7 days. For longer storage, dried mushrooms last up to 12 months in a cool, dry place.' },
  { q: 'Do you ship pan-India?', a: 'We currently deliver fresh mushrooms within Odisha. For dried and packaged varieties, we ship pan-India via courier. Check the delivery estimator on the product page.' },
  { q: 'How are the mushrooms packaged?', a: 'We use eco-friendly, biodegradable packaging. Fresh mushrooms come in breathable paper bags. Dried products are vacuum-sealed to lock in freshness.' }
];

const reviews = [
  { name: 'Priya Pattnaik', location: 'Bhubaneswar', rating: 5, text: 'Absolutely the freshest mushrooms I have ever bought online! The Shiitake arrived in perfect condition and the taste is incredible. Will not buy anywhere else now.', date: '2 weeks ago' },
  { name: 'Rajan Sharma', location: 'Cuttack', rating: 5, text: 'Ordered the Mixed Combo Box as a gift for my wife who loves cooking. She was absolutely thrilled! The packaging is beautiful and the quality is restaurant-grade.', date: '1 month ago' },
  { name: 'Deepa Mohanty', location: 'Sambalpur', rating: 5, text: 'As a chef, I have very high standards for ingredients. MycōMart\'s Oyster mushrooms are consistently excellent. I order every week for my restaurant.', date: '3 weeks ago' },
  { name: 'Suresh Kumar', location: 'Angul', rating: 5, text: 'Supporting local business and getting the best quality — this is the dream. Ankit and his brothers have done an outstanding job. Very proud of this from Angul!', date: '1 week ago' },
  { name: 'Meena Biswal', location: 'Rourkela', rating: 4, text: 'Great products and very responsive customer service. Delivery was prompt. I did have one small issue with an order but they resolved it immediately with a replacement.', date: '5 days ago' },
  { name: 'Ashok Nanda', location: 'Berhampur', rating: 5, text: 'The dried Shiitake pack is absolutely amazing. I use it to make the most flavourful broth. 100g lasts a whole month. Excellent value for money!', date: '2 months ago' }
];

// ─── DOM UTILITIES ──────────────────────────────────────────
const $ = (s, el = document) => el.querySelector(s);
const $$ = (s, el = document) => [...el.querySelectorAll(s)];

function createElement(tag, classes = '', html = '') {
  const el = document.createElement(tag);
  if (classes) el.className = classes;
  if (html) el.innerHTML = html;
  return el;
}

// ─── THEME ──────────────────────────────────────────────────
function initTheme() {
  document.documentElement.setAttribute('data-theme', state.theme);
  $$('.dark-toggle').forEach(btn => {
    btn.setAttribute('title', state.theme === 'dark' ? 'Switch to Light Mode' : 'Switch to Dark Mode');
  });
}

function toggleTheme() {
  state.theme = state.theme === 'dark' ? 'light' : 'dark';
  localStorage.setItem('mycomart_theme', state.theme);
  initTheme();
}

// ─── CART ───────────────────────────────────────────────────
function saveCart() {
  localStorage.setItem('mycomart_cart', JSON.stringify(state.cart));
  updateCartUI();
}

function addToCart(productId, weight, qty = 1) {
  const product = products.find(p => p.id === productId);
  if (!product) return;
  const key = `${productId}_${weight}`;
  const existing = state.cart.find(i => i.key === key);
  if (existing) {
    existing.qty += qty;
  } else {
    state.cart.push({
      key,
      productId,
      weight,
      qty,
      name: product.name,
      emoji: product.emoji,
      price: product.prices[weight] || Object.values(product.prices)[0]
    });
  }
  saveCart();
  showToast(`🛒 Added ${product.name} (${weight}) to cart!`, 'success');
  renderCartItems();
}

function removeFromCart(key) {
  state.cart = state.cart.filter(i => i.key !== key);
  saveCart();
  renderCartItems();
}

function updateCartQty(key, delta) {
  const item = state.cart.find(i => i.key === key);
  if (!item) return;
  item.qty = Math.max(1, item.qty + delta);
  saveCart();
  renderCartItems();
}

function getCartTotal() {
  return state.cart.reduce((s, i) => s + i.price * i.qty, 0);
}

function getCartCount() {
  return state.cart.reduce((s, i) => s + i.qty, 0);
}

function updateCartUI() {
  const count = getCartCount();
  $$('.cart-count').forEach(el => {
    el.textContent = count;
    el.style.display = count > 0 ? 'flex' : 'none';
  });
}

function renderCartItems() {
  const container = $('#cart-items-list');
  if (!container) return;
  if (state.cart.length === 0) {
    container.innerHTML = `
      <div style="text-align:center; padding:3rem 1rem;">
        <div style="font-size:4rem; margin-bottom:1rem;">🛒</div>
        <div style="font-family:'Playfair Display',serif; font-size:1.25rem; font-weight:700; margin-bottom:0.5rem;">Your cart is empty</div>
        <div style="color:var(--text-muted); font-size:0.9rem;">Browse our fresh mushrooms and add them here.</div>
      </div>`;
    const totalEl = $('#cart-total-val');
    if (totalEl) totalEl.textContent = '₹0';
    return;
  }

  container.innerHTML = state.cart.map(item => `
    <div class="cart-item" data-key="${item.key}">
      <div class="cart-item-img">${item.emoji}</div>
      <div style="flex:1;">
        <div class="cart-item-name">${item.name}</div>
        <div class="cart-item-variant">${item.weight}</div>
        <div class="qty-controls">
          <button class="qty-btn" onclick="updateCartQty('${item.key}', -1)">−</button>
          <span class="qty-num">${item.qty}</span>
          <button class="qty-btn" onclick="updateCartQty('${item.key}', 1)">+</button>
          <button style="margin-left:auto;color:var(--text-muted);font-size:1rem;padding:4px;" onclick="removeFromCart('${item.key}')">🗑</button>
        </div>
      </div>
      <div class="cart-item-price">₹${(item.price * item.qty).toLocaleString('en-IN')}</div>
    </div>`).join('');

  const totalEl = $('#cart-total-val');
  if (totalEl) totalEl.textContent = `₹${getCartTotal().toLocaleString('en-IN')}`;
}

function openCart() {
  renderCartItems();
  const overlay = $('#cart-overlay');
  const sidebar = $('#cart-sidebar');
  if (overlay) overlay.classList.add('active');
  if (sidebar) sidebar.classList.add('active');
  document.body.style.overflow = 'hidden';
}

function closeCart() {
  const overlay = $('#cart-overlay');
  const sidebar = $('#cart-sidebar');
  if (overlay) overlay.classList.remove('active');
  if (sidebar) sidebar.classList.remove('active');
  document.body.style.overflow = '';
}

// ─── WISHLIST ───────────────────────────────────────────────
function toggleWishlist(productId) {
  const idx = state.wishlist.indexOf(productId);
  if (idx > -1) {
    state.wishlist.splice(idx, 1);
    showToast('💔 Removed from wishlist', 'info');
  } else {
    state.wishlist.push(productId);
    showToast('❤️ Added to wishlist!', 'success');
  }
  localStorage.setItem('mycomart_wishlist', JSON.stringify(state.wishlist));
  updateWishlistUI();
}

function updateWishlistUI() {
  $$('[data-wishlist]').forEach(btn => {
    const id = parseInt(btn.dataset.wishlist);
    btn.style.color = state.wishlist.includes(id) ? '#e53e3e' : '';
  });
  const countEl = $('.wishlist-count');
  if (countEl) {
    countEl.textContent = state.wishlist.length;
    countEl.style.display = state.wishlist.length > 0 ? 'flex' : 'none';
  }
}

// ─── PRODUCT CARD RENDERER ──────────────────────────────────
function renderProductCard(product, selectedWeight = null) {
  const weights = Object.keys(product.prices);
  const activeWeight = selectedWeight || weights[0];
  const price = product.prices[activeWeight];
  const original = product.originalPrices[activeWeight];
  const discount = Math.round((1 - price / original) * 100);
  const stars = '★'.repeat(Math.floor(product.rating)) + (product.rating % 1 >= 0.5 ? '⭐' : '');

  return `
    <div class="product-card" onclick="navigateTo('product', ${product.id})">
      <div class="product-card-image">
        <div class="product-emoji">${product.emoji}</div>
        <div class="product-badge-wrap">
          <span class="badge ${product.badgeColor}">${product.badge}</span>
        </div>
        <div class="product-actions-overlay">
          <button class="product-action-icon" title="Add to Wishlist" onclick="event.stopPropagation(); toggleWishlist(${product.id})" data-wishlist="${product.id}">❤</button>
          <button class="product-action-icon" title="Quick View" onclick="event.stopPropagation(); quickView(${product.id})">👁</button>
          <button class="product-action-icon" title="Compare">⚖</button>
        </div>
      </div>
      <div class="product-card-body">
        <div class="product-category-tag">${product.categoryLabel}</div>
        <div class="product-name">${product.name}</div>
        <div class="product-rating">
          <span class="stars">★★★★★</span>
          <span style="font-weight:700; font-size:0.875rem;">${product.rating}</span>
          <span class="rating-count">(${product.reviews})</span>
        </div>
        <div class="product-price-row">
          <span class="price-current">₹${price}</span>
          <span class="price-original">₹${original}</span>
          <span class="price-discount">${discount}% off</span>
        </div>
        <div class="weight-options" data-product="${product.id}">
          ${weights.map(w => `
            <button class="weight-btn ${w === activeWeight ? 'active' : ''}"
              onclick="event.stopPropagation(); selectWeight(this, ${product.id}, '${w}')">${w}</button>
          `).join('')}
        </div>
        <button class="product-add-btn" onclick="event.stopPropagation(); addToCart(${product.id}, '${activeWeight}')">
          🛒 Add to Cart
        </button>
      </div>
    </div>`;
}

function selectWeight(btn, productId, weight) {
  const card = btn.closest('.product-card');
  $$('.weight-btn', card).forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  const product = products.find(p => p.id === productId);
  if (!product) return;
  const price = product.prices[weight];
  const original = product.originalPrices[weight];
  const discount = Math.round((1 - price / original) * 100);
  const priceEl = $('.price-current', card);
  const origEl = $('.price-original', card);
  const discEl = $('.price-discount', card);
  if (priceEl) priceEl.textContent = `₹${price}`;
  if (origEl) origEl.textContent = `₹${original}`;
  if (discEl) discEl.textContent = `${discount}% off`;
  const addBtn = $('.product-add-btn', card);
  if (addBtn) addBtn.onclick = (e) => { e.stopPropagation(); addToCart(productId, weight); };
}

function quickView(productId) {
  const product = products.find(p => p.id === productId);
  if (!product) return;
  showToast(`🍄 Opening ${product.name}...`, 'info');
  setTimeout(() => navigateTo('product', productId), 400);
}

// ─── TOAST ──────────────────────────────────────────────────
function showToast(message, type = 'success') {
  let container = $('#toast-container');
  if (!container) {
    container = createElement('div', 'toast-container');
    container.id = 'toast-container';
    document.body.appendChild(container);
  }
  const toast = createElement('div', 'toast');
  const icons = { success: '✅', error: '❌', info: 'ℹ️', warning: '⚠️' };
  toast.innerHTML = `
    <span class="toast-icon">${icons[type] || '📢'}</span>
    <span class="toast-text">${message}</span>
    <span class="toast-close" onclick="this.parentElement.remove()">✕</span>`;
  container.appendChild(toast);
  setTimeout(() => { if (toast.parentElement) toast.remove(); }, 4000);
}

// ─── SEARCH ─────────────────────────────────────────────────
function handleSearch(query) {
  const dropdown = $('#search-dropdown');
  if (!dropdown) return;
  if (!query.trim()) { dropdown.classList.remove('active'); return; }
  const results = products.filter(p =>
    p.name.toLowerCase().includes(query.toLowerCase()) ||
    p.categoryLabel.toLowerCase().includes(query.toLowerCase())
  ).slice(0, 5);
  if (results.length === 0) { dropdown.classList.remove('active'); return; }
  dropdown.innerHTML = results.map(p => `
    <div class="search-item" onclick="navigateTo('product', ${p.id})">
      <div class="search-item-img">${p.emoji}</div>
      <div>
        <div style="font-weight:600; font-size:0.875rem;">${p.name}</div>
        <div style="font-size:0.8rem; color:var(--text-muted);">${p.categoryLabel} · From ₹${Object.values(p.prices)[0]}</div>
      </div>
    </div>`).join('');
  dropdown.classList.add('active');
}

// ─── NAVIGATION ─────────────────────────────────────────────
function navigateTo(page, param = null) {
  state.currentPage = page;
  const main = $('#page-content');
  if (!main) return;

  // Update active nav
  $$('.nav-link, .mobile-nav-link').forEach(l => {
    l.classList.toggle('active', l.dataset.page === page);
  });

  // Scroll to top
  window.scrollTo({ top: 0, behavior: 'smooth' });

  // Close mobile menu
  const mobilePanel = $('#mobile-menu-panel');
  if (mobilePanel) mobilePanel.classList.remove('active');

  switch(page) {
    case 'home': renderHome(); break;
    case 'shop': renderShop(param); break;
    case 'product': renderProductDetail(param); break;
    case 'cart': renderCartPage(); break;
    case 'checkout': renderCheckout(); break;
    case 'wishlist': renderWishlist(); break;
    case 'about': renderAbout(); break;
    case 'blog': renderBlog(); break;
    case 'faq': renderFaq(); break;
    case 'contact': renderContact(); break;
    case 'login': renderLogin(); break;
    case 'register': renderRegister(); break;
    case 'dashboard': renderUserDashboard(); break;
    case 'admin': renderAdminDashboard(); break;
    case 'farmer': renderFarmerDashboard(); break;
    case 'tracking': renderTracking(); break;
    case 'ai-detect': renderAIDetect(); break;
    default: renderHome();
  }

  // Trigger reveal animations
  setTimeout(() => {
    $$('.reveal').forEach(el => {
      const observer = new IntersectionObserver((entries) => {
        entries.forEach(e => { if (e.isIntersecting) e.target.classList.add('visible'); });
      }, { threshold: 0.1 });
      observer.observe(el);
    });
  }, 100);
}

// ─── HOME PAGE ──────────────────────────────────────────────
function renderHome() {
  const main = $('#page-content');
  const featuredProducts = products.slice(0, 4);
  const bestSellers = products.filter(p => p.tags.includes('bestseller'));

  main.innerHTML = `
    <!-- HERO -->
    <section class="hero">
      <div class="hero-bg"></div>
      <div class="hero-pattern"></div>
      <div class="hero-content">
        <div class="fade-in">
          <div class="hero-eyebrow">🌿 Farm-Fresh from Angul, Odisha</div>
          <h1 class="hero-title">
            Nature's Finest <span class="highlight">Mushrooms</span>,
            Straight from Our Farm
          </h1>
          <p class="hero-desc">
            Grown with love by the Patel brothers at Pokatunga, Bantala — 
            organic, fresh, and delivered to your door within 24 hours.
          </p>
          <div class="hero-cta">
            <button class="btn btn-primary btn-lg" onclick="navigateTo('shop')">🛒 Shop Now</button>
            <button class="btn btn-secondary btn-lg" onclick="navigateTo('about')">Our Story</button>
          </div>
          <div class="hero-stats">
            <div>
              <div class="hero-stat-num">500+</div>
              <div class="hero-stat-label">Happy Customers</div>
            </div>
            <div>
              <div class="hero-stat-num">3</div>
              <div class="hero-stat-label">Mushroom Varieties</div>
            </div>
            <div>
              <div class="hero-stat-num">24hr</div>
              <div class="hero-stat-label">Fresh Delivery</div>
            </div>
          </div>
        </div>
        <div class="hero-visual fade-in fade-in-delay-2">
          <div class="hero-card-main">
            <div class="hero-mushroom-display">🍄</div>
            <div style="text-align:center;">
              <div style="font-family:'Playfair Display',serif; font-size:1.1rem; font-weight:700;">Premium Mixed Box</div>
              <div style="color:var(--text-muted); font-size:0.875rem; margin-bottom:1rem;">Button + Oyster + Shiitake</div>
              <div style="display:flex; align-items:center; justify-content:center; gap:0.75rem;">
                <span style="font-family:'Playfair Display',serif; font-size:1.5rem; font-weight:900; color:var(--forest);">₹199</span>
                <span style="color:var(--text-muted); text-decoration:line-through; font-size:0.9rem;">₹260</span>
                <span class="badge badge-gold">23% off</span>
              </div>
            </div>
            <div class="hero-badge-float hero-badge-float-1">
              <span>🌿</span> <span>100% Organic</span>
            </div>
            <div class="hero-badge-float hero-badge-float-2">
              <span>⭐</span> <span>4.9 Rating</span>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- CATEGORIES -->
    <section class="section" style="background:var(--bg-primary);">
      <div class="container">
        <div class="section-header reveal">
          <div class="section-eyebrow">🍄 Our Varieties</div>
          <h2 class="section-title">Shop by Category</h2>
          <p class="section-desc">Three premium mushroom varieties, grown fresh on our Odisha farm and available year-round</p>
        </div>
        <div class="categories-grid reveal">
          <div class="category-card cat-button" onclick="navigateTo('shop','button')">
            <div class="cat-bg">🍄</div>
            <div class="cat-body">
              <div class="cat-name">Button Mushroom</div>
              <div class="cat-desc">Mild, creamy flavour. Perfect for everyday cooking — curries, soups, stir-fry.</div>
              <div class="cat-count">3 products · From ₹65</div>
            </div>
          </div>
          <div class="category-card cat-oyster" onclick="navigateTo('shop','oyster')">
            <div class="cat-bg">🫐</div>
            <div class="cat-body">
              <div class="cat-name">Oyster Mushroom</div>
              <div class="cat-desc">Delicate, fan-shaped clusters. Available in Blue, Gold, and Pink varieties.</div>
              <div class="cat-count">3 products · From ₹85</div>
            </div>
          </div>
          <div class="category-card cat-shiitake" onclick="navigateTo('shop','shiitake')">
            <div class="cat-bg">🌰</div>
            <div class="cat-body">
              <div class="cat-name">Shiitake Mushroom</div>
              <div class="cat-desc">Rich umami. The medicinal powerhouse — also available in dried pack.</div>
              <div class="cat-count">2 products · From ₹110</div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- FEATURED PRODUCTS -->
    <section class="section" style="background:var(--bg-secondary);">
      <div class="container">
        <div class="section-header reveal">
          <div class="section-eyebrow">⭐ Featured</div>
          <h2 class="section-title">Freshly Picked for You</h2>
          <p class="section-desc">Harvested this week from our Pokatunga farm — as fresh as it gets</p>
        </div>
        <div class="products-grid reveal">
          ${featuredProducts.map(p => renderProductCard(p)).join('')}
        </div>
        <div style="text-align:center; margin-top:2.5rem;">
          <button class="btn btn-secondary btn-lg" onclick="navigateTo('shop')">View All Products →</button>
        </div>
      </div>
    </section>

    <!-- BEST SELLERS -->
    <section class="section" style="background:var(--bg-primary);">
      <div class="container">
        <div class="section-header reveal">
          <div class="section-eyebrow">🔥 Best Sellers</div>
          <h2 class="section-title">Customer Favourites</h2>
          <p class="section-desc">The mushrooms our customers order again and again</p>
        </div>
        <div class="products-grid reveal">
          ${bestSellers.map(p => renderProductCard(p)).join('')}
        </div>
      </div>
    </section>

    <!-- HEALTH BENEFITS -->
    <section class="section" style="background:var(--bg-secondary);">
      <div class="container">
        <div class="section-header reveal">
          <div class="section-eyebrow">💚 Why Mushrooms</div>
          <h2 class="section-title">Nature's Nutritional Powerhouse</h2>
          <p class="section-desc">Backed by science. Grown with love. Benefits you can feel.</p>
        </div>
        <div class="benefits-grid reveal">
          ${[
            { icon: '🛡️', title: 'Immunity Booster', desc: 'Rich in beta-glucans and polysaccharides that activate the immune system and increase resistance to infections.' },
            { icon: '🧠', title: 'Brain Health', desc: 'Lion\'s mane and Shiitake compounds support cognitive function, memory, and reduce risk of neurodegenerative diseases.' },
            { icon: '❤️', title: 'Heart Friendly', desc: 'Oyster mushrooms contain lovastatin, a natural cholesterol reducer that supports cardiovascular health.' },
            { icon: '⚖️', title: 'Weight Management', desc: 'Low calorie, high fibre, and high protein — mushrooms keep you full longer while supporting a healthy weight.' },
            { icon: '🦴', title: 'Bone Strength', desc: 'Sun-exposed mushrooms are one of the few natural plant sources of Vitamin D, essential for bone density.' },
            { icon: '🔋', title: 'Energy & Vitality', desc: 'B vitamins in mushrooms convert food into energy and support adrenal function for sustained daily vitality.' }
          ].map(b => `
            <div class="benefit-card">
              <div class="benefit-icon">${b.icon}</div>
              <div class="benefit-title">${b.title}</div>
              <div class="benefit-desc">${b.desc}</div>
            </div>`).join('')}
        </div>
      </div>
    </section>

    <!-- BROTHERS STORY (PREVIEW) -->
    <section class="section story-section">
      <div class="container">
        <div class="story-grid">
          <div class="reveal">
            <div class="section-eyebrow">👨‍👨‍👦 Our Story</div>
            <h2 class="section-title" style="text-align:left;">Three Brothers, One Dream</h2>
            <p style="font-size:1.0625rem; color:var(--text-secondary); line-height:1.8; margin-bottom:1.5rem;">
              Ankit, Amulya, and Amit Patel grew up in the quiet village of Pokatunga, Bantala in Angul District.
              What started as an experiment in their family's backyard shed has grown into MycōMart — 
              Odisha's most trusted mushroom brand.
            </p>
            <p style="font-size:1.0625rem; color:var(--text-secondary); line-height:1.8; margin-bottom:2rem;">
              Armed with agricultural degrees, passion for organic farming, and the belief that fresh food 
              should be accessible to all, they built their farm from scratch in 2022.
            </p>
            <div class="brothers-grid">
              ${[
                { name: 'Ankit', role: 'Farm Operations', initial: 'A' },
                { name: 'Amulya', role: 'Quality & R&D', initial: 'Am' },
                { name: 'Amit', role: 'Sales & Marketing', initial: 'At' }
              ].map(b => `
                <div class="brother-card">
                  <div class="brother-avatar">${b.initial}</div>
                  <div class="brother-name">${b.name}</div>
                  <div class="brother-role">${b.role}</div>
                </div>`).join('')}
            </div>
            <div style="margin-top:2rem;">
              <button class="btn btn-primary" onclick="navigateTo('about')">Read Full Story →</button>
            </div>
          </div>
          <div class="reveal fade-in-delay-2">
            <div class="story-visual">
              <div class="farm-showcase">🌱</div>
              <div class="farm-detail farm-detail-1">
                <div style="font-weight:700; font-size:0.9rem;">📍 Our Farm</div>
                <div style="font-size:0.8rem; color:var(--text-muted);">Pokatunga, Bantala<br>Angul, Odisha</div>
              </div>
              <div class="farm-detail farm-detail-2">
                <div style="font-weight:700; font-size:0.9rem;">🏆 Established</div>
                <div style="font-size:0.8rem; color:var(--text-muted);">2022 · NPOP Certified</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- REVIEWS -->
    <section class="section" style="background:var(--bg-primary);">
      <div class="container">
        <div class="section-header reveal">
          <div class="section-eyebrow">💬 Reviews</div>
          <h2 class="section-title">What Our Customers Say</h2>
          <div style="display:flex; align-items:center; justify-content:center; gap:0.5rem; margin-top:0.5rem;">
            <span style="color:var(--gold); font-size:1.25rem;">★★★★★</span>
            <span style="font-family:'Playfair Display',serif; font-size:1.25rem; font-weight:700;">4.9</span>
            <span style="color:var(--text-muted);">· Based on 1,200+ reviews</span>
          </div>
        </div>
        <div class="reviews-grid reveal">
          ${reviews.map(r => `
            <div class="review-card">
              <div class="review-header">
                <div class="reviewer-avatar">${r.name[0]}</div>
                <div>
                  <div class="reviewer-name">${r.name}</div>
                  <div style="display:flex; gap:0.5rem; align-items:center;">
                    <span style="color:var(--gold); font-size:0.8rem;">★★★★★</span>
                    <span class="reviewer-date">${r.date}</span>
                  </div>
                  <div style="font-size:0.75rem; color:var(--text-muted);">📍 ${r.location}</div>
                </div>
              </div>
              <p class="review-text">${r.text}</p>
            </div>`).join('')}
        </div>
      </div>
    </section>

    <!-- NEWSLETTER -->
    <section class="section newsletter-section">
      <div class="container" style="text-align:center;">
        <div class="section-eyebrow" style="color:var(--mist); justify-content:center;">📧 Stay Connected</div>
        <h2 class="section-title" style="color:var(--white); margin-bottom:1rem;">Get Fresh Updates</h2>
        <p style="color:rgba(255,255,255,0.75); font-size:1.0625rem; margin-bottom:2rem; max-width:480px; margin-left:auto; margin-right:auto;">
          Subscribe for weekly farm news, seasonal offers, mushroom recipes, and early access to new products.
        </p>
        <div class="newsletter-form">
          <input type="email" class="newsletter-input" placeholder="Enter your email address">
          <button class="newsletter-btn" onclick="subscribeNewsletter(this)">Subscribe 🌿</button>
        </div>
        <p style="margin-top:1rem; font-size:0.8rem; color:rgba(255,255,255,0.5);">No spam. Unsubscribe anytime. By subscribing, you agree to our privacy policy.</p>
      </div>
    </section>

    <!-- BLOG PREVIEW -->
    <section class="section" style="background:var(--bg-secondary);">
      <div class="container">
        <div class="section-header reveal">
          <div class="section-eyebrow">📖 Blog</div>
          <h2 class="section-title">From the Farm & Kitchen</h2>
        </div>
        <div class="blog-grid reveal">
          ${blogPosts.slice(0,3).map(p => `
            <div class="blog-card" onclick="navigateTo('blog')">
              <div class="blog-thumb">${p.emoji}</div>
              <div class="blog-body">
                <div class="blog-meta">
                  <span class="badge badge-green">${p.category}</span>
                  <span class="blog-date">${p.date}</span>
                </div>
                <div class="blog-title">${p.title}</div>
                <div class="blog-excerpt">${p.excerpt}</div>
                <div class="blog-read-more">Read More <span>→</span></div>
              </div>
            </div>`).join('')}
        </div>
      </div>
    </section>
  `;
}

// ─── SHOP PAGE ──────────────────────────────────────────────
function renderShop(filterCategory = null) {
  const main = $('#page-content');
  let filteredProducts = filterCategory ? products.filter(p => p.category === filterCategory) : [...products];

  main.innerHTML = `
    <div class="page-hero">
      <div class="container">
        <div class="breadcrumb">
          <a onclick="navigateTo('home')">Home</a> <span>›</span>
          <span>Shop</span>
          ${filterCategory ? `<span>›</span><span style="text-transform:capitalize;">${filterCategory} Mushrooms</span>` : ''}
        </div>
        <h1 class="display-md">Fresh Mushroom Shop</h1>
        <p style="color:var(--text-secondary); margin-top:0.5rem;">Farm-fresh. Organic. Delivered within 24 hours.</p>
      </div>
    </div>
    <div class="container">
      <div class="shop-layout">
        <aside class="filter-sidebar" id="shop-filter-sidebar">
          <div class="filter-card">
            <div class="filter-title">Categories ▾</div>
            ${[['all','All Products'],['button','Button Mushroom'],['oyster','Oyster Mushroom'],['shiitake','Shiitake Mushroom']].map(([val, label]) => `
              <div class="filter-item ${(!filterCategory && val === 'all') || filterCategory === val ? 'checked' : ''}" onclick="filterShop('${val}')">
                <div class="filter-checkbox">${((!filterCategory && val === 'all') || filterCategory === val) ? '✓' : ''}</div>
                <span>${label}</span>
              </div>`).join('')}
          </div>
          <div class="filter-card">
            <div class="filter-title">Price Range ▾</div>
            ${[['all','All Prices'],['low','Under ₹100'],['mid','₹100 – ₹200'],['high','Above ₹200']].map(([val, label]) => `
              <div class="filter-item" onclick="filterByPrice('${val}')">
                <div class="filter-checkbox"></div>
                <span>${label}</span>
              </div>`).join('')}
          </div>
          <div class="filter-card">
            <div class="filter-title">Tags ▾</div>
            ${['organic','premium','bestseller','dried','fresh','rare','gift'].map(tag => `
              <div class="filter-item">
                <div class="filter-checkbox"></div>
                <span style="text-transform:capitalize;">${tag}</span>
              </div>`).join('')}
          </div>
          <div class="filter-card">
            <div class="filter-title">Rating ▾</div>
            ${['5','4+','3+'].map(r => `
              <div class="filter-item">
                <div class="filter-checkbox"></div>
                <span>${r === '5' ? '★★★★★ only' : r === '4+' ? '★★★★☆ & above' : '★★★☆☆ & above'}</span>
              </div>`).join('')}
          </div>
        </aside>
        <div>
          <div class="sort-bar">
            <span class="results-count">Showing <strong>${filteredProducts.length}</strong> products</span>
            <div style="display:flex; gap:0.75rem; align-items:center; flex-wrap:wrap;">
              <button class="btn btn-ghost btn-sm" onclick="toggleFilterSidebar()">🔧 Filters</button>
              <select class="sort-select" onchange="sortProducts(this.value)">
                <option value="featured">Sort: Featured</option>
                <option value="price-low">Price: Low to High</option>
                <option value="price-high">Price: High to Low</option>
                <option value="rating">Highest Rated</option>
                <option value="reviews">Most Reviewed</option>
              </select>
            </div>
          </div>
          <div class="products-grid" id="shop-products-grid">
            ${filteredProducts.map(p => renderProductCard(p)).join('')}
          </div>
        </div>
      </div>
    </div>`;
}

function filterShop(category) {
  navigateTo('shop', category === 'all' ? null : category);
}

function filterByPrice(range) {
  showToast('🔧 Price filter applied!', 'info');
}

function sortProducts(val) {
  showToast(`📊 Sorted by ${val}`, 'info');
}

function toggleFilterSidebar() {
  const sidebar = $('#shop-filter-sidebar');
  if (sidebar) sidebar.style.display = sidebar.style.display === 'block' ? '' : 'block';
}

// ─── PRODUCT DETAIL PAGE ─────────────────────────────────────
function renderProductDetail(productId) {
  const product = products.find(p => p.id === productId);
  if (!product) { navigateTo('shop'); return; }
  const weights = Object.keys(product.prices);
  const main = $('#page-content');
  const related = products.filter(p => p.category === product.category && p.id !== product.id).slice(0, 4);

  main.innerHTML = `
    <div class="page-hero" style="padding:2rem 0;">
      <div class="container">
        <div class="breadcrumb">
          <a onclick="navigateTo('home')">Home</a> <span>›</span>
          <a onclick="navigateTo('shop')">Shop</a> <span>›</span>
          <span>${product.categoryLabel}</span> <span>›</span>
          <span>${product.name}</span>
        </div>
      </div>
    </div>
    <div class="container">
      <div class="product-detail-grid">
        <div class="product-gallery">
          <div class="gallery-main" id="gallery-main">${product.emoji}</div>
          <div class="gallery-thumbs">
            ${[product.emoji, '🌱', '📦', '⭐'].map((e, i) => `
              <div class="gallery-thumb ${i === 0 ? 'active' : ''}" onclick="setGalleryEmoji('${e}', this)">${e}</div>`).join('')}
          </div>
        </div>
        <div class="product-info" id="product-info-panel">
          <div class="badge ${product.badgeColor}" style="margin-bottom:1rem;">${product.badge}</div>
          <h1 class="product-detail-name">${product.name}</h1>
          <div class="product-meta">
            <div class="product-rating">
              <span class="stars">★★★★★</span>
              <span style="font-weight:700;">${product.rating}</span>
              <span class="rating-count">(${product.reviews} reviews)</span>
            </div>
            <span class="badge badge-green">✓ In Stock</span>
          </div>
          <div class="product-price-row" style="margin-bottom:1.5rem;">
            <span class="price-big" id="detail-price">₹${Object.values(product.prices)[0]}</span>
            <span class="price-original" id="detail-original">₹${Object.values(product.originalPrices)[0]}</span>
            <span class="price-discount" id="detail-discount">${Math.round((1 - Object.values(product.prices)[0] / Object.values(product.originalPrices)[0]) * 100)}% off</span>
          </div>
          <p style="color:var(--text-secondary); margin-bottom:1.5rem; line-height:1.7;">${product.longDesc}</p>
          
          <div style="margin-bottom:1.5rem;">
            <div style="font-weight:700; margin-bottom:0.75rem; font-size:0.9375rem;">Select Weight:</div>
            <div class="weight-options" id="detail-weights">
              ${weights.map((w, i) => `
                <button class="weight-btn ${i === 0 ? 'active' : ''}" 
                  onclick="selectDetailWeight('${w}', this)">${w}</button>`).join('')}
            </div>
          </div>
          
          <div class="quantity-control">
            <span style="font-weight:700; font-size:0.9375rem;">Quantity:</span>
            <div class="qty-input-wrap">
              <div class="qty-input-btn" onclick="changeDetailQty(-1)">−</div>
              <input type="number" class="qty-input-num" id="detail-qty" value="1" min="1" max="20">
              <div class="qty-input-btn" onclick="changeDetailQty(1)">+</div>
            </div>
          </div>
          
          <div class="product-cta-group">
            <button class="btn btn-primary btn-lg" onclick="addDetailToCart(${product.id})">🛒 Add to Cart</button>
            <button class="btn btn-accent btn-lg" onclick="buyNow(${product.id})">⚡ Buy Now</button>
          </div>
          <div style="margin-bottom:1.5rem; display:flex; gap:0.75rem;">
            <button class="btn btn-ghost" onclick="toggleWishlist(${product.id})" data-wishlist="${product.id}">❤ Add to Wishlist</button>
            <button class="btn btn-ghost">📤 Share</button>
          </div>
          
          <div class="product-features">
            ${[
              ['🚚', 'Free Delivery', 'On orders above ₹299 within Odisha'],
              ['🌿', 'Organic Certified', 'NPOP certified, pesticide-free'],
              ['❄️', 'Cold Chain', 'Temperature-controlled logistics'],
              ['🔄', 'Easy Returns', '100% freshness guarantee'],
              ['📍', 'Farm Fresh', 'Pokatunga, Bantala, Angul, Odisha']
            ].map(([icon, title, desc]) => `
              <div class="feature-item">
                <span class="feature-icon">${icon}</span>
                <div>
                  <div style="font-weight:700; font-size:0.875rem;">${title}</div>
                  <div style="font-size:0.8rem; color:var(--text-muted);">${desc}</div>
                </div>
              </div>`).join('')}
          </div>
        </div>
      </div>

      <!-- TABS -->
      <div style="margin: 3rem 0;">
        <div class="tabs">
          ${['Description', 'Nutrition Info', 'Reviews', 'Farming Process'].map((t, i) => `
            <button class="tab-btn ${i === 0 ? 'active' : ''}" onclick="switchTab(this, 'tab-${i}')">${t}</button>`).join('')}
        </div>
        <div class="tab-panel active" id="tab-0">
          <p style="line-height:1.8; color:var(--text-secondary); margin-bottom:1.5rem;">${product.longDesc}</p>
          <h4 style="font-family:'Playfair Display',serif; margin-bottom:1rem;">Key Benefits</h4>
          <div style="display:flex; flex-wrap:wrap; gap:0.5rem;">
            ${product.benefits.map(b => `<span class="badge badge-green">✓ ${b}</span>`).join('')}
          </div>
        </div>
        <div class="tab-panel" id="tab-1">
          <div class="grid-2" style="max-width:600px;">
            ${Object.entries(product.nutrition).map(([k, v]) => `
              <div style="padding:1rem; background:var(--bg-secondary); border-radius:var(--radius-md); border:1px solid var(--border);">
                <div style="font-size:0.8rem; color:var(--text-muted); text-transform:uppercase; letter-spacing:0.06em; margin-bottom:0.25rem;">${k.replace(/_/g,' ')}</div>
                <div style="font-weight:700; font-size:1.1rem; font-family:'Playfair Display',serif;">${v}</div>
              </div>`).join('')}
          </div>
        </div>
        <div class="tab-panel" id="tab-2">
          <div class="reviews-grid">
            ${reviews.slice(0, 3).map(r => `
              <div class="review-card">
                <div class="review-header">
                  <div class="reviewer-avatar">${r.name[0]}</div>
                  <div>
                    <div class="reviewer-name">${r.name}</div>
                    <div style="color:var(--gold); font-size:0.8rem;">★★★★★</div>
                  </div>
                </div>
                <p class="review-text">${r.text}</p>
              </div>`).join('')}
          </div>
        </div>
        <div class="tab-panel" id="tab-3">
          <p style="line-height:1.8; color:var(--text-secondary);">
            Our mushrooms are grown using substrate-based cultivation on a combination of wheat straw and rice bran, 
            sourced locally from Angul district farmers. The growing environment maintains 85-95% humidity and 
            18-24°C temperature for optimal yield and nutrition. Each batch is tested for contamination before harvest.
          </p>
          <div style="margin-top:2rem; display:flex; gap:2rem; flex-wrap:wrap;">
            ${['Substrate Prep', 'Inoculation', 'Incubation', 'Fruiting', 'Harvest', 'QC & Pack'].map((s, i) => `
              <div style="text-align:center; flex:1; min-width:80px;">
                <div style="width:44px; height:44px; background:var(--forest); color:white; border-radius:50%; display:flex; align-items:center; justify-content:center; font-weight:700; margin:0 auto 0.5rem;">${i + 1}</div>
                <div style="font-size:0.8rem; font-weight:600;">${s}</div>
              </div>`).join('')}
          </div>
        </div>
      </div>

      <!-- RELATED -->
      ${related.length > 0 ? `
        <div style="margin-bottom:4rem;">
          <h3 style="font-family:'Playfair Display',serif; font-size:1.5rem; margin-bottom:1.5rem;">Related Products</h3>
          <div class="products-grid">
            ${related.map(p => renderProductCard(p)).join('')}
          </div>
        </div>` : ''}
    </div>`;

  // Set up detail page state
  window._detailProduct = product;
  window._detailWeight = weights[0];
}

function setGalleryEmoji(emoji, thumb) {
  const main = $('#gallery-main');
  if (main) main.textContent = emoji;
  $$('.gallery-thumb').forEach(t => t.classList.remove('active'));
  if (thumb) thumb.classList.add('active');
}

function selectDetailWeight(weight, btn) {
  $$('#detail-weights .weight-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  window._detailWeight = weight;
  const product = window._detailProduct;
  if (!product) return;
  const price = product.prices[weight];
  const orig = product.originalPrices[weight];
  const disc = Math.round((1 - price / orig) * 100);
  const priceEl = $('#detail-price');
  const origEl = $('#detail-original');
  const discEl = $('#detail-discount');
  if (priceEl) priceEl.textContent = `₹${price}`;
  if (origEl) origEl.textContent = `₹${orig}`;
  if (discEl) discEl.textContent = `${disc}% off`;
}

function changeDetailQty(delta) {
  const input = $('#detail-qty');
  if (!input) return;
  input.value = Math.max(1, parseInt(input.value) + delta);
}

function addDetailToCart(productId) {
  const weight = window._detailWeight || Object.keys(products.find(p => p.id === productId)?.prices || {})[0];
  const qty = parseInt($('#detail-qty')?.value || '1');
  addToCart(productId, weight, qty);
  openCart();
}

function buyNow(productId) {
  const weight = window._detailWeight || Object.keys(products.find(p => p.id === productId)?.prices || {})[0];
  addToCart(productId, weight, 1);
  navigateTo('checkout');
}

function switchTab(btn, tabId) {
  $$('.tab-btn').forEach(b => b.classList.remove('active'));
  $$('.tab-panel').forEach(p => p.classList.remove('active'));
  btn.classList.add('active');
  const panel = $(`#${tabId}`);
  if (panel) panel.classList.add('active');
}

// ─── CART PAGE ──────────────────────────────────────────────
function renderCartPage() {
  const main = $('#page-content');
  const total = getCartTotal();
  const shipping = total > 299 ? 0 : 49;

  main.innerHTML = `
    <div class="page-hero">
      <div class="container">
        <div class="breadcrumb"><a onclick="navigateTo('home')">Home</a> <span>›</span> <span>Cart</span></div>
        <h1 class="display-md">Your Cart</h1>
      </div>
    </div>
    <div class="container" style="padding-top:2rem; padding-bottom:4rem;">
      ${state.cart.length === 0 ? `
        <div style="text-align:center; padding:5rem 0;">
          <div style="font-size:5rem; margin-bottom:1.5rem;">🛒</div>
          <h2 style="font-family:'Playfair Display',serif; margin-bottom:1rem;">Your cart is empty</h2>
          <p style="color:var(--text-muted); margin-bottom:2rem;">Browse our fresh mushrooms and add them to your cart.</p>
          <button class="btn btn-primary btn-lg" onclick="navigateTo('shop')">Shop Now</button>
        </div>` : `
        <div style="display:grid; grid-template-columns:1fr 380px; gap:2rem; align-items:start;">
          <div>
            <div style="display:flex; flex-direction:column; gap:1rem;" id="cart-page-items">
              ${state.cart.map(item => `
                <div class="cart-item" style="background:var(--bg-card);" data-key="${item.key}">
                  <div class="cart-item-img">${item.emoji}</div>
                  <div style="flex:1;">
                    <div class="cart-item-name">${item.name}</div>
                    <div class="cart-item-variant">${item.weight}</div>
                    <div class="qty-controls">
                      <button class="qty-btn" onclick="updateCartQty('${item.key}', -1); renderCartPage()">−</button>
                      <span class="qty-num">${item.qty}</span>
                      <button class="qty-btn" onclick="updateCartQty('${item.key}', 1); renderCartPage()">+</button>
                    </div>
                  </div>
                  <div style="text-align:right;">
                    <div class="cart-item-price">₹${(item.price * item.qty).toLocaleString('en-IN')}</div>
                    <button style="color:var(--text-muted); font-size:0.8rem; margin-top:0.5rem;" onclick="removeFromCart('${item.key}'); renderCartPage()">Remove</button>
                  </div>
                </div>`).join('')}
            </div>
          </div>
          <div class="order-summary-card">
            <div class="order-summary-title">Order Summary</div>
            <div class="summary-row"><span>Subtotal</span><span>₹${total.toLocaleString('en-IN')}</span></div>
            <div class="summary-row"><span>Shipping</span><span>${shipping === 0 ? '<span style="color:var(--fern);">FREE</span>' : `₹${shipping}`}</span></div>
            ${shipping > 0 ? `<div style="font-size:0.8rem; color:var(--fern); margin-bottom:0.75rem;">Add ₹${299 - total} more for free shipping</div>` : ''}
            <div class="summary-row"><span>GST (5%)</span><span>₹${Math.round(total * 0.05).toLocaleString('en-IN')}</span></div>
            <div class="summary-divider"></div>
            <div class="summary-row summary-total">
              <span>Total</span>
              <span class="summary-total-val">₹${(total + shipping + Math.round(total * 0.05)).toLocaleString('en-IN')}</span>
            </div>
            <button class="btn btn-primary w-full btn-lg" style="margin-top:1.25rem;" onclick="navigateTo('checkout')">Proceed to Checkout →</button>
            <button class="btn btn-ghost w-full" style="margin-top:0.75rem;" onclick="navigateTo('shop')">Continue Shopping</button>
          </div>
        </div>`}
    </div>`;
}

// ─── CHECKOUT PAGE ──────────────────────────────────────────
function renderCheckout() {
  const main = $('#page-content');
  const total = getCartTotal();
  const shipping = total > 299 ? 0 : 49;
  const gst = Math.round(total * 0.05);
  const grand = total + shipping + gst;

  main.innerHTML = `
    <div class="page-hero">
      <div class="container">
        <div class="breadcrumb"><a onclick="navigateTo('home')">Home</a> <span>›</span> <a onclick="navigateTo('cart')">Cart</a> <span>›</span> <span>Checkout</span></div>
        <h1 class="display-md">Checkout</h1>
      </div>
    </div>
    <div class="container">
      <div class="checkout-grid">
        <div>
          <!-- Shipping Address -->
          <div class="checkout-form-section">
            <div class="checkout-section-title"><span class="step-num">1</span> Shipping Address</div>
            <div class="form-row">
              <div class="form-group"><label class="form-label">First Name</label><input class="form-input" placeholder="Rajan" type="text"></div>
              <div class="form-group"><label class="form-label">Last Name</label><input class="form-input" placeholder="Sharma" type="text"></div>
            </div>
            <div class="form-group"><label class="form-label">Phone Number</label><input class="form-input" placeholder="+91 9XXXXXXXXX" type="tel"></div>
            <div class="form-group"><label class="form-label">Email</label><input class="form-input" placeholder="your@email.com" type="email"></div>
            <div class="form-group"><label class="form-label">Address Line 1</label><input class="form-input" placeholder="House no, Street name" type="text"></div>
            <div class="form-group"><label class="form-label">Address Line 2 (optional)</label><input class="form-input" placeholder="Apartment, colony, landmark" type="text"></div>
            <div class="form-row">
              <div class="form-group"><label class="form-label">City</label><input class="form-input" placeholder="Angul" type="text"></div>
              <div class="form-group"><label class="form-label">Pincode</label><input class="form-input" placeholder="759XXX" type="text"></div>
            </div>
            <div class="form-row">
              <div class="form-group"><label class="form-label">State</label>
                <select class="form-input sort-select" style="height:48px; border-radius:var(--radius-md);">
                  <option>Odisha</option><option>West Bengal</option><option>Jharkhand</option><option>Chhattisgarh</option><option>Other</option>
                </select>
              </div>
              <div class="form-group"><label class="form-label">Country</label><input class="form-input" value="India" type="text"></div>
            </div>
          </div>

          <!-- Payment -->
          <div class="checkout-form-section">
            <div class="checkout-section-title"><span class="step-num">2</span> Payment Method</div>
            <div class="payment-methods">
              ${[
                { id: 'upi', icon: '📱', label: 'UPI Payment', sub: 'GPay, PhonePe, Paytm, BHIM' },
                { id: 'card', icon: '💳', label: 'Credit / Debit Card', sub: 'Visa, MasterCard, Rupay' },
                { id: 'netbanking', icon: '🏦', label: 'Net Banking', sub: 'All major Indian banks' },
                { id: 'cod', icon: '💵', label: 'Cash on Delivery', sub: 'Pay when your order arrives' }
              ].map((m, i) => `
                <div class="payment-option ${i === 0 ? 'selected' : ''}" onclick="selectPayment(this)">
                  <div class="payment-radio"></div>
                  <span style="font-size:1.25rem;">${m.icon}</span>
                  <div>
                    <div style="font-weight:700; font-size:0.9375rem;">${m.label}</div>
                    <div style="font-size:0.8rem; color:var(--text-muted);">${m.sub}</div>
                  </div>
                </div>`).join('')}
            </div>
            <div id="upi-details" style="margin-top:1.25rem; padding:1.25rem; background:var(--bg-secondary); border-radius:var(--radius-md); border:1px solid var(--border);">
              <div class="form-group mb-0"><label class="form-label">UPI ID</label><input class="form-input" placeholder="yourname@paytm / @gpay" type="text"></div>
            </div>
          </div>

          <!-- Promo Code -->
          <div class="checkout-form-section">
            <div class="checkout-section-title"><span class="step-num">3</span> Promo Code</div>
            <div style="display:flex; gap:0.75rem;">
              <input class="form-input" placeholder="Enter promo code (try: FRESH20)" id="promo-input" style="flex:1;">
              <button class="btn btn-secondary" onclick="applyPromo()">Apply</button>
            </div>
            <div id="promo-msg" style="margin-top:0.5rem; font-size:0.875rem;"></div>
          </div>
        </div>

        <!-- Order Summary -->
        <div class="order-summary-card">
          <div class="order-summary-title">Order Summary</div>
          <div class="summary-items">
            ${state.cart.map(item => `
              <div class="summary-item">
                <div class="summary-item-img">${item.emoji}</div>
                <div>
                  <div class="summary-item-name">${item.name}</div>
                  <div class="summary-item-sub">${item.weight} × ${item.qty}</div>
                </div>
                <div class="summary-item-price">₹${(item.price * item.qty).toLocaleString('en-IN')}</div>
              </div>`).join('')}
          </div>
          <div class="summary-divider"></div>
          <div class="summary-row"><span>Subtotal</span><span>₹${total.toLocaleString('en-IN')}</span></div>
          <div class="summary-row"><span>Shipping</span><span>${shipping === 0 ? '<span style="color:var(--fern);">FREE</span>' : `₹${shipping}`}</span></div>
          <div class="summary-row"><span>GST (5%)</span><span>₹${gst.toLocaleString('en-IN')}</span></div>
          <div class="summary-divider"></div>
          <div class="summary-row summary-total"><span>Total</span><span class="summary-total-val">₹${grand.toLocaleString('en-IN')}</span></div>
          <div style="margin:1rem 0; padding:0.875rem; background:rgba(74,124,94,0.08); border-radius:var(--radius-md); font-size:0.85rem; color:var(--fern); font-weight:600;">
            🚚 Estimated delivery: 1-2 business days
          </div>
          <button class="btn btn-primary w-full btn-lg" onclick="placeOrder()" style="font-size:1.0625rem;">
            Place Order · ₹${grand.toLocaleString('en-IN')}
          </button>
          <p style="font-size:0.75rem; color:var(--text-muted); text-align:center; margin-top:1rem;">
            🔒 SSL Secured · 100% Freshness Guarantee
          </p>
        </div>
      </div>
    </div>`;
}

function selectPayment(el) {
  $$('.payment-option').forEach(o => o.classList.remove('selected'));
  el.classList.add('selected');
}

function applyPromo() {
  const code = $('#promo-input')?.value?.toUpperCase().trim();
  const msg = $('#promo-msg');
  if (!msg) return;
  if (code === 'FRESH20') {
    msg.innerHTML = '<span style="color:var(--fern);">✓ Promo FRESH20 applied! 20% discount added.</span>';
  } else if (code === 'MYCOMART10') {
    msg.innerHTML = '<span style="color:var(--fern);">✓ Welcome discount of 10% applied!</span>';
  } else {
    msg.innerHTML = '<span style="color:#e53e3e;">✗ Invalid promo code. Try FRESH20</span>';
  }
}

function placeOrder() {
  showToast('🎉 Order placed successfully! You will receive a confirmation shortly.', 'success');
  state.cart = [];
  saveCart();
  setTimeout(() => navigateTo('tracking'), 1500);
}

// ─── WISHLIST PAGE ───────────────────────────────────────────
function renderWishlist() {
  const main = $('#page-content');
  const wishlistProducts = products.filter(p => state.wishlist.includes(p.id));

  main.innerHTML = `
    <div class="page-hero">
      <div class="container">
        <div class="breadcrumb"><a onclick="navigateTo('home')">Home</a> <span>›</span> <span>Wishlist</span></div>
        <h1 class="display-md">My Wishlist</h1>
        <p style="color:var(--text-muted); margin-top:0.5rem;">${wishlistProducts.length} item${wishlistProducts.length !== 1 ? 's' : ''} saved</p>
      </div>
    </div>
    <div class="container" style="padding:3rem 0;">
      ${wishlistProducts.length === 0 ? `
        <div style="text-align:center; padding:5rem 0;">
          <div style="font-size:5rem; margin-bottom:1.5rem;">❤️</div>
          <h2 style="font-family:'Playfair Display',serif; margin-bottom:1rem;">Your wishlist is empty</h2>
          <p style="color:var(--text-muted); margin-bottom:2rem;">Save your favourite mushrooms to revisit later.</p>
          <button class="btn btn-primary btn-lg" onclick="navigateTo('shop')">Browse Products</button>
        </div>` : `
        <div class="products-grid">
          ${wishlistProducts.map(p => renderProductCard(p)).join('')}
        </div>`}
    </div>`;
}

// ─── ABOUT PAGE ──────────────────────────────────────────────
function renderAbout() {
  const main = $('#page-content');
  main.innerHTML = `
    <div class="page-hero">
      <div class="container">
        <div class="breadcrumb"><a onclick="navigateTo('home')">Home</a> <span>›</span> <span>About Us</span></div>
        <h1 class="display-md">Our Story</h1>
        <p style="color:var(--text-secondary); margin-top:0.5rem; font-size:1.0625rem;">From a backyard shed in Angul to Odisha's trusted mushroom brand</p>
      </div>
    </div>

    <!-- Story Section -->
    <section class="section">
      <div class="container">
        <div class="story-grid">
          <div class="reveal">
            <div class="section-eyebrow">🌱 The Beginning</div>
            <h2 class="section-title" style="text-align:left;">How MycōMart Was Born</h2>
            <p style="color:var(--text-secondary); line-height:1.8; margin-bottom:1.25rem;">
              In 2020, Ankit Patel, the eldest of three brothers, returned to his village of Pokatunga in Bantala,
              Angul after completing his B.Sc. in Agriculture. Armed with knowledge of sustainable farming but 
              limited resources, he began experimenting with mushroom cultivation in a small shed on their family land.
            </p>
            <p style="color:var(--text-secondary); line-height:1.8; margin-bottom:1.25rem;">
              His younger brothers Amulya and Amit soon joined him — Amulya bringing his biology background 
              for quality research, and Amit handling the marketing and sales with his business management degree.
              What started as a 200 sq ft experiment grew rapidly.
            </p>
            <p style="color:var(--text-secondary); line-height:1.8; margin-bottom:2rem;">
              By 2022, they officially launched MycōMart, offering fresh Button, Oyster, and Shiitake mushrooms 
              to local markets. Today they operate a 5,000 sq ft farm, serve 500+ customers across Odisha, 
              and are expanding their cold-chain delivery network.
            </p>
          </div>
          <div class="reveal" style="display:flex; flex-direction:column; gap:1.5rem;">
            <div class="farm-showcase" style="font-size:5rem; padding:2rem;">🌾</div>
            <div style="display:grid; grid-template-columns:1fr 1fr; gap:1rem;">
              ${[
                { num: '2022', label: 'Founded' },
                { num: '5000 sq ft', label: 'Farm Area' },
                { num: '500+', label: 'Customers' },
                { num: '3', label: 'Varieties' }
              ].map(s => `
                <div style="text-align:center; padding:1.25rem; background:var(--bg-card); border:1px solid var(--border); border-radius:var(--radius-md);">
                  <div style="font-family:'Playfair Display',serif; font-size:1.5rem; font-weight:900; color:var(--forest);">${s.num}</div>
                  <div style="font-size:0.8rem; color:var(--text-muted);">${s.label}</div>
                </div>`).join('')}
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- Brothers -->
    <section class="section" style="background:var(--bg-secondary);">
      <div class="container">
        <div class="section-header reveal">
          <div class="section-eyebrow">👨‍👨‍👦 The Team</div>
          <h2 class="section-title">Meet the Brothers</h2>
        </div>
        <div class="grid-3 reveal">
          ${[
            { name: 'Ankit Patel', role: 'Founder & Farm Operations Head', emoji: '🌱', desc: 'The visionary behind MycōMart. Ankit oversees daily farm operations, substrate preparation, and cultivation. He holds a B.Sc. Agriculture from OUAT and has 5+ years of mushroom cultivation experience.', skills: ['Cultivation', 'Farm Management', 'Sustainability'] },
            { name: 'Amulya Patel', role: 'Co-Founder & Quality Director', emoji: '🔬', desc: 'Amulya ensures every mushroom meets MycōMart\'s strict quality standards. He leads the R&D team, manages organic certification compliance, and oversees nutritional testing of all products.', skills: ['Quality Control', 'R&D', 'NPOP Compliance'] },
            { name: 'Amit Patel', role: 'Co-Founder & Sales & Marketing', emoji: '📈', desc: 'Amit built MycōMart\'s brand from scratch — from local market vendor to a recognized online brand. He manages customer relationships, marketing campaigns, and the e-commerce expansion.', skills: ['Marketing', 'Sales', 'Brand Building'] }
          ].map(b => `
            <div class="card" style="padding:2rem; text-align:center;">
              <div style="font-size:4rem; margin-bottom:1rem;">${b.emoji}</div>
              <div style="width:80px; height:80px; background:linear-gradient(135deg, var(--forest), var(--sage)); border-radius:50%; display:flex; align-items:center; justify-content:center; color:white; font-family:'Playfair Display',serif; font-size:1.5rem; font-weight:900; margin:0 auto 1rem;">${b.name[0]}</div>
              <h3 style="font-family:'Playfair Display',serif; font-size:1.25rem; margin-bottom:0.25rem;">${b.name}</h3>
              <p style="color:var(--fern); font-size:0.875rem; font-weight:600; margin-bottom:1rem;">${b.role}</p>
              <p style="font-size:0.875rem; color:var(--text-secondary); line-height:1.7; margin-bottom:1.25rem;">${b.desc}</p>
              <div style="display:flex; flex-wrap:wrap; gap:0.35rem; justify-content:center;">
                ${b.skills.map(s => `<span class="badge badge-green">${s}</span>`).join('')}
              </div>
            </div>`).join('')}
        </div>
      </div>
    </section>

    <!-- Mission -->
    <section class="section">
      <div class="container">
        <div class="section-header reveal">
          <div class="section-eyebrow">🎯 Our Mission</div>
          <h2 class="section-title">What We Stand For</h2>
        </div>
        <div class="grid-3 reveal">
          ${[
            { icon: '🌿', title: 'Organic First', desc: 'We farm without synthetic pesticides or chemicals. Every product carries the same care we would want for our own family.' },
            { icon: '🤝', title: 'Community Impact', desc: 'We employ 12+ local farmers from Bantala and Angul, creating sustainable livelihoods while growing premium produce.' },
            { icon: '♻️', title: 'Eco-Conscious', desc: 'Biodegradable packaging, zero food waste (spent substrate becomes compost), and solar-powered cold storage.' }
          ].map(m => `
            <div class="benefit-card">
              <div class="benefit-icon">${m.icon}</div>
              <div class="benefit-title">${m.title}</div>
              <div class="benefit-desc">${m.desc}</div>
            </div>`).join('')}
        </div>
      </div>
    </section>
  `;
}

// ─── BLOG PAGE ──────────────────────────────────────────────
function renderBlog() {
  const main = $('#page-content');
  main.innerHTML = `
    <div class="page-hero">
      <div class="container">
        <div class="breadcrumb"><a onclick="navigateTo('home')">Home</a> <span>›</span> <span>Blog</span></div>
        <h1 class="display-md">The MycōMart Journal</h1>
        <p style="color:var(--text-secondary); margin-top:0.5rem;">Farm stories, health guides, recipes & more</p>
      </div>
    </div>
    <div class="container" style="padding:3rem 0;">
      <div style="display:flex; gap:0.75rem; flex-wrap:wrap; margin-bottom:2.5rem;">
        ${['All', 'Farm Story', 'Health', 'Recipes', 'Farming Guide', 'Science'].map((cat, i) => `
          <button class="btn ${i === 0 ? 'btn-primary' : 'btn-ghost'} btn-sm" onclick="filterBlog('${cat}', this)">${cat}</button>`).join('')}
      </div>
      <div class="blog-grid">
        ${blogPosts.map(p => `
          <div class="blog-card">
            <div class="blog-thumb">${p.emoji}</div>
            <div class="blog-body">
              <div class="blog-meta">
                <span class="badge badge-green">${p.category}</span>
                <span class="blog-date">${p.date}</span>
                <span style="font-size:0.75rem; color:var(--text-muted);">⏱ ${p.readTime}</span>
              </div>
              <div class="blog-title">${p.title}</div>
              <div class="blog-excerpt">${p.excerpt}</div>
              <div class="blog-read-more">Read Article <span>→</span></div>
            </div>
          </div>`).join('')}
      </div>
    </div>`;
}

function filterBlog(cat, btn) {
  $$('[onclick*="filterBlog"]').forEach(b => { b.className = b.className.replace('btn-primary', 'btn-ghost'); });
  btn.className = btn.className.replace('btn-ghost', 'btn-primary');
  showToast(`📖 Showing ${cat} articles`, 'info');
}

// ─── FAQ PAGE ────────────────────────────────────────────────
function renderFaq() {
  const main = $('#page-content');
  main.innerHTML = `
    <div class="page-hero">
      <div class="container">
        <div class="breadcrumb"><a onclick="navigateTo('home')">Home</a> <span>›</span> <span>FAQ</span></div>
        <h1 class="display-md">Frequently Asked Questions</h1>
        <p style="color:var(--text-secondary); margin-top:0.5rem;">Everything you need to know about MycōMart and our mushrooms</p>
      </div>
    </div>
    <div class="container-sm" style="padding:3rem 1.5rem 5rem;">
      <div style="margin-bottom:2rem;">
        <div class="nav-search" style="max-width:100%;">
          <span class="nav-search-icon">🔍</span>
          <input class="nav-search-input" placeholder="Search questions..." oninput="filterFaqs(this.value)">
        </div>
      </div>
      <div id="faq-list">
        ${faqs.map((f, i) => `
          <div class="faq-item" id="faq-${i}">
            <div class="faq-question" onclick="toggleFaq(${i})">${f.q}<span class="faq-icon">+</span></div>
            <div class="faq-answer">${f.a}</div>
          </div>`).join('')}
      </div>
      <div style="margin-top:3rem; text-align:center; padding:2rem; background:var(--bg-secondary); border-radius:var(--radius-lg); border:1px solid var(--border);">
        <div style="font-size:2rem; margin-bottom:1rem;">💬</div>
        <h3 style="font-family:'Playfair Display',serif; margin-bottom:0.5rem;">Still have questions?</h3>
        <p style="color:var(--text-muted); margin-bottom:1.5rem;">We're happy to help! Reach out to us directly.</p>
        <button class="btn btn-primary" onclick="navigateTo('contact')">Contact Us</button>
      </div>
    </div>`;
}

function toggleFaq(index) {
  const item = $(`#faq-${index}`);
  if (item) item.classList.toggle('open');
}

function filterFaqs(query) {
  faqs.forEach((f, i) => {
    const item = $(`#faq-${i}`);
    if (item) {
      const match = f.q.toLowerCase().includes(query.toLowerCase()) || f.a.toLowerCase().includes(query.toLowerCase());
      item.style.display = match ? '' : 'none';
    }
  });
}

// ─── CONTACT PAGE ────────────────────────────────────────────
function renderContact() {
  const main = $('#page-content');
  main.innerHTML = `
    <div class="page-hero">
      <div class="container">
        <div class="breadcrumb"><a onclick="navigateTo('home')">Home</a> <span>›</span> <span>Contact</span></div>
        <h1 class="display-md">Get in Touch</h1>
        <p style="color:var(--text-secondary); margin-top:0.5rem;">We'd love to hear from you. Write us, call us, or visit our farm.</p>
      </div>
    </div>
    <div class="container">
      <div class="contact-grid">
        <!-- Form -->
        <div>
          <div class="checkout-form-section">
            <h3 style="font-family:'Playfair Display',serif; font-size:1.25rem; margin-bottom:1.5rem;">Send a Message</h3>
            <div class="form-row">
              <div class="form-group"><label class="form-label">Your Name</label><input class="form-input" placeholder="Full Name" type="text"></div>
              <div class="form-group"><label class="form-label">Email</label><input class="form-input" placeholder="your@email.com" type="email"></div>
            </div>
            <div class="form-group"><label class="form-label">Phone</label><input class="form-input" placeholder="+91 9XXXXXXXXX" type="tel"></div>
            <div class="form-group"><label class="form-label">Subject</label>
              <select class="form-input sort-select" style="height:48px; border-radius:var(--radius-md);">
                <option>Order Inquiry</option><option>Wholesale / Bulk Order</option><option>Product Question</option><option>Farm Visit</option><option>Partnership</option><option>Feedback</option>
              </select>
            </div>
            <div class="form-group"><label class="form-label">Message</label><textarea class="form-input form-textarea" placeholder="Tell us how we can help..." rows="5"></textarea></div>
            <button class="btn btn-primary btn-lg w-full" onclick="submitContact()">Send Message 🌿</button>
          </div>
        </div>
        <!-- Info -->
        <div>
          <div class="contact-info-card">
            <h3 style="font-family:'Playfair Display',serif; font-size:1.25rem;">Contact Information</h3>
            ${[
              { icon: '📍', title: 'Farm Address', text: 'Pokatunga, Bantala, Angul District\nOdisha – 759XXX, India' },
              { icon: '📞', title: 'Phone / WhatsApp', text: '+91 94370 XXXXX\n+91 85250 XXXXX' },
              { icon: '📧', title: 'Email', text: 'hello@mycomart.in\nwholesale@mycomart.in' },
              { icon: '🕐', title: 'Working Hours', text: 'Mon–Sat: 7 AM – 7 PM\nSunday: 8 AM – 2 PM' }
            ].map(c => `
              <div class="contact-detail">
                <div class="contact-icon">${c.icon}</div>
                <div>
                  <div class="contact-detail-title">${c.title}</div>
                  <div class="contact-detail-text">${c.text.replace(/\n/g, '<br>')}</div>
                </div>
              </div>`).join('')}
            <div class="social-links">
              ${['📘 Facebook','📸 Instagram','▶️ YouTube','🐦 Twitter'].map(s => `
                <div class="social-link" title="${s.split(' ')[1]}" style="font-size:1.2rem;">${s.split(' ')[0]}</div>`).join('')}
            </div>
          </div>
          <!-- Map Placeholder -->
          <div class="map-container">
            <div class="map-placeholder">
              <div style="font-size:4rem; margin-bottom:1rem;">🗺️</div>
              <h3 style="font-family:'Playfair Display',serif; margin-bottom:0.5rem;">Pokatunga, Bantala</h3>
              <p style="color:var(--text-secondary); font-size:0.9rem;">Angul District, Odisha, India</p>
              <a href="https://maps.google.com/?q=Angul,Odisha,India" target="_blank" class="btn btn-primary btn-sm" style="margin-top:1rem;">Open in Google Maps →</a>
            </div>
          </div>
        </div>
      </div>
    </div>`;
}

function submitContact() {
  showToast('✉️ Message sent! We\'ll respond within 24 hours.', 'success');
}

// ─── LOGIN PAGE ──────────────────────────────────────────────
function renderLogin() {
  const main = $('#page-content');
  main.innerHTML = `
    <div class="auth-page">
      <div class="auth-card">
        <div class="auth-logo">
          <div style="font-size:2.5rem; margin-bottom:0.5rem;">🍄</div>
          <div style="font-family:'Playfair Display',serif; font-size:1.5rem; font-weight:900; color:var(--forest);">MycōMart</div>
        </div>
        <div class="auth-title">Welcome Back</div>
        <div class="auth-sub">Sign in to your account to continue</div>
        <div class="form-group"><label class="form-label">Email Address</label><input class="form-input" placeholder="your@email.com" type="email"></div>
        <div class="form-group"><label class="form-label">Password</label><input class="form-input" placeholder="••••••••" type="password"></div>
        <div style="display:flex; justify-content:flex-end; margin-bottom:1.5rem;">
          <a href="#" style="font-size:0.875rem; color:var(--fern); font-weight:600;">Forgot Password?</a>
        </div>
        <button class="btn btn-primary w-full btn-lg" onclick="showToast('👋 Welcome back!', 'success'); navigateTo('dashboard')">Sign In</button>
        <div class="auth-divider">or continue with</div>
        <div style="display:grid; grid-template-columns:1fr 1fr; gap:0.75rem; margin-bottom:1.5rem;">
          <button class="btn btn-ghost" onclick="showToast('Google login coming soon', 'info')">🔵 Google</button>
          <button class="btn btn-ghost" onclick="showToast('Phone login coming soon', 'info')">📱 Phone OTP</button>
        </div>
        <p style="text-align:center; font-size:0.9rem; color:var(--text-muted);">
          Don't have an account? <a href="#" onclick="navigateTo('register')" style="color:var(--fern); font-weight:700;">Sign Up</a>
        </p>
      </div>
    </div>`;
}

function renderRegister() {
  const main = $('#page-content');
  main.innerHTML = `
    <div class="auth-page">
      <div class="auth-card">
        <div class="auth-logo">
          <div style="font-size:2.5rem; margin-bottom:0.5rem;">🍄</div>
          <div style="font-family:'Playfair Display',serif; font-size:1.5rem; font-weight:900; color:var(--forest);">MycōMart</div>
        </div>
        <div class="auth-title">Create Account</div>
        <div class="auth-sub">Join MycōMart for fresh mushroom delivery</div>
        <div class="form-row">
          <div class="form-group"><label class="form-label">First Name</label><input class="form-input" placeholder="First Name" type="text"></div>
          <div class="form-group"><label class="form-label">Last Name</label><input class="form-input" placeholder="Last Name" type="text"></div>
        </div>
        <div class="form-group"><label class="form-label">Email</label><input class="form-input" placeholder="your@email.com" type="email"></div>
        <div class="form-group"><label class="form-label">Phone</label><input class="form-input" placeholder="+91 9XXXXXXXXX" type="tel"></div>
        <div class="form-group"><label class="form-label">Password</label><input class="form-input" placeholder="Create a strong password" type="password"></div>
        <div style="margin-bottom:1.5rem; font-size:0.8rem; color:var(--text-muted);">
          By registering, you agree to our <a style="color:var(--fern);">Terms & Conditions</a> and <a style="color:var(--fern);">Privacy Policy</a>
        </div>
        <button class="btn btn-primary w-full btn-lg" onclick="showToast('🎉 Account created!', 'success'); navigateTo('dashboard')">Create Account</button>
        <p style="text-align:center; font-size:0.9rem; color:var(--text-muted); margin-top:1.5rem;">
          Already have an account? <a href="#" onclick="navigateTo('login')" style="color:var(--fern); font-weight:700;">Sign In</a>
        </p>
      </div>
    </div>`;
}

// ─── USER DASHBOARD ──────────────────────────────────────────
function renderUserDashboard() {
  const main = $('#page-content');
  main.innerHTML = `
    <div class="dashboard-layout">
      <aside class="dashboard-sidebar">
        <div style="text-align:center; padding:0.5rem 0 1.5rem;">
          <div style="width:72px; height:72px; background:linear-gradient(135deg, var(--forest), var(--sage)); border-radius:50%; display:flex; align-items:center; justify-content:center; color:white; font-size:1.75rem; font-weight:900; font-family:'Playfair Display',serif; margin:0 auto 0.75rem;">R</div>
          <div style="font-weight:700;">Rajan Sharma</div>
          <div style="font-size:0.8rem; color:var(--text-muted);">rajan@email.com</div>
        </div>
        <nav class="sidebar-menu">
          ${[
            ['📊','Overview','dashboard'],['📦','My Orders','dashboard'],['❤️','Wishlist','wishlist'],
            ['📍','Saved Addresses','dashboard'],['👤','Profile Settings','dashboard'],
            ['🔔','Notifications','dashboard'],['🚪','Logout','home']
          ].map(([icon, label, page], i) => `
            <div class="sidebar-item ${i === 0 ? 'active' : ''}" onclick="navigateTo('${page}')">
              <span class="sidebar-icon">${icon}</span>${label}
            </div>`).join('')}
        </nav>
      </aside>
      <div class="dashboard-content">
        <div style="margin-bottom:2rem;">
          <h2 style="font-family:'Playfair Display',serif; font-size:1.5rem;">My Dashboard</h2>
          <p style="color:var(--text-muted);">Welcome back, Rajan! Here's your account summary.</p>
        </div>
        <div class="stats-grid">
          ${[
            { label:'Total Orders', value:'12', change:'+3 this month', emoji:'📦', up: true },
            { label:'Total Spent', value:'₹2,840', change:'Lifetime value', emoji:'💰', up: true },
            { label:'Wishlist Items', value: state.wishlist.length.toString(), change:'Items saved', emoji:'❤️', up: false },
            { label:'Loyalty Points', value:'285', change:'+45 this month', emoji:'⭐', up: true }
          ].map(s => `
            <div class="stat-card" data-emoji="${s.emoji}">
              <div class="stat-label">${s.label}</div>
              <div class="stat-value">${s.value}</div>
              <div class="stat-change ${s.up ? 'up' : ''}">${s.up ? '↑' : ''} ${s.change}</div>
            </div>`).join('')}
        </div>

        <!-- Recent Orders -->
        <div class="table-card" style="margin-bottom:2rem;">
          <div class="table-header">
            <div class="table-title">Recent Orders</div>
            <button class="btn btn-ghost btn-sm">View All</button>
          </div>
          <div style="overflow-x:auto;">
            <table class="data-table">
              <thead><tr><th>Order ID</th><th>Product</th><th>Date</th><th>Amount</th><th>Status</th><th>Action</th></tr></thead>
              <tbody>
                ${[
                  { id:'#MM-1042', product:'Mixed Combo Box (1kg)', date:'Mar 10, 2025', amount:'₹490', status:'Delivered', statusColor:'badge-green' },
                  { id:'#MM-1037', product:'Shiitake Mushroom (500g)', date:'Feb 28, 2025', amount:'₹270', status:'Delivered', statusColor:'badge-green' },
                  { id:'#MM-1029', product:'Oyster Mushroom (250g)', date:'Feb 14, 2025', amount:'₹110', status:'Delivered', statusColor:'badge-green' },
                  { id:'#MM-1018', product:'Button Mushroom (1kg)', date:'Jan 30, 2025', amount:'₹225', status:'Delivered', statusColor:'badge-green' }
                ].map(o => `
                  <tr>
                    <td style="font-family:'DM Mono',monospace; font-size:0.875rem;">${o.id}</td>
                    <td style="font-weight:600;">${o.product}</td>
                    <td style="color:var(--text-muted);">${o.date}</td>
                    <td style="font-weight:700;">${o.amount}</td>
                    <td><span class="badge ${o.statusColor}">${o.status}</span></td>
                    <td><button class="btn btn-ghost btn-sm" onclick="navigateTo('tracking')">Track</button></td>
                  </tr>`).join('')}
              </tbody>
            </table>
          </div>
        </div>

        <!-- Saved Addresses -->
        <div class="table-card">
          <div class="table-header">
            <div class="table-title">Saved Addresses</div>
            <button class="btn btn-primary btn-sm" onclick="showToast('Address form coming soon!', 'info')">+ Add New</button>
          </div>
          <div style="padding:1.5rem; display:flex; flex-direction:column; gap:1rem;">
            ${[
              { label:'Home', address:'42, Tagore Nagar, Angul, Odisha - 759122', default:true },
              { label:'Office', address:'Block D, Industrial Estate, Cuttack, Odisha - 753001', default:false }
            ].map(a => `
              <div style="padding:1.25rem; border:1.5px solid ${a.default ? 'var(--fern)' : 'var(--border)'}; border-radius:var(--radius-md); display:flex; align-items:flex-start; justify-content:space-between; gap:1rem;">
                <div>
                  <div style="display:flex; align-items:center; gap:0.5rem; margin-bottom:0.5rem;">
                    <span style="font-weight:700;">${a.label}</span>
                    ${a.default ? '<span class="badge badge-green">Default</span>' : ''}
                  </div>
                  <div style="font-size:0.875rem; color:var(--text-secondary);">${a.address}</div>
                </div>
                <div style="display:flex; gap:0.5rem; flex-shrink:0;">
                  <button class="btn btn-ghost btn-sm">Edit</button>
                  ${!a.default ? '<button class="btn btn-ghost btn-sm">Delete</button>' : ''}
                </div>
              </div>`).join('')}
          </div>
        </div>
      </div>
    </div>`;
}

// ─── ADMIN DASHBOARD ─────────────────────────────────────────
function renderAdminDashboard() {
  const main = $('#page-content');
  main.innerHTML = `
    <div class="dashboard-layout">
      <aside class="dashboard-sidebar">
        <div style="padding:0.5rem 0.5rem 1.5rem;">
          <div style="font-family:'Playfair Display',serif; font-size:1.1rem; font-weight:900; color:var(--forest);">🍄 MycōMart Admin</div>
          <div style="font-size:0.75rem; color:var(--text-muted); margin-top:0.25rem;">Admin Dashboard</div>
        </div>
        <nav class="sidebar-menu">
          ${[
            ['📊','Dashboard','admin'],['📦','Orders','admin'],['🛍️','Products','admin'],
            ['👥','Customers','admin'],['📈','Analytics','admin'],['🌾','Farmer Portal','farmer'],
            ['🤖','AI Tools','ai-detect'],['⚙️','Settings','admin'],['🚪','Back to Site','home']
          ].map(([icon, label, page], i) => `
            <div class="sidebar-item ${i === 0 ? 'active' : ''}" onclick="navigateTo('${page}')">
              <span class="sidebar-icon">${icon}</span>${label}
            </div>`).join('')}
        </nav>
      </aside>
      <div class="dashboard-content">
        <div style="display:flex; align-items:center; justify-content:space-between; margin-bottom:2rem;">
          <div>
            <h2 style="font-family:'Playfair Display',serif; font-size:1.5rem;">Admin Dashboard</h2>
            <p style="color:var(--text-muted);">MycōMart · Angul, Odisha · Today's Overview</p>
          </div>
          <div style="display:flex; gap:0.75rem;">
            <button class="btn btn-ghost btn-sm">Export Data</button>
            <button class="btn btn-primary btn-sm" onclick="showToast('New product form opening!', 'info')">+ Add Product</button>
          </div>
        </div>

        <div class="stats-grid" style="grid-template-columns:repeat(4,1fr);">
          ${[
            { label:'Revenue Today', value:'₹8,240', change:'+22% vs yesterday', emoji:'💰', up:true },
            { label:'Orders Today', value:'34', change:'+8 from yesterday', emoji:'📦', up:true },
            { label:'Total Customers', value:'512', change:'+12 this week', emoji:'👥', up:true },
            { label:'Stock Alert', value:'3 items', change:'Low inventory', emoji:'⚠️', up:false }
          ].map(s => `
            <div class="stat-card" data-emoji="${s.emoji}">
              <div class="stat-label">${s.label}</div>
              <div class="stat-value">${s.value}</div>
              <div class="stat-change ${s.up ? 'up' : 'down'}">${s.up ? '↑' : '↓'} ${s.change}</div>
            </div>`).join('')}
        </div>

        <!-- Product Management -->
        <div class="table-card" style="margin-bottom:2rem;">
          <div class="table-header">
            <div class="table-title">Product Management</div>
            <div style="display:flex; gap:0.5rem;">
              <input style="padding:0.5rem 1rem; border:1px solid var(--border); border-radius:var(--radius-full); background:var(--bg-secondary); color:var(--text-primary); font-size:0.875rem;" placeholder="Search products...">
              <button class="btn btn-primary btn-sm">+ Add Product</button>
            </div>
          </div>
          <div style="overflow-x:auto;">
            <table class="data-table">
              <thead><tr><th>Product</th><th>Category</th><th>Stock (1kg)</th><th>Price (250g)</th><th>Rating</th><th>Status</th><th>Actions</th></tr></thead>
              <tbody>
                ${products.map(p => `
                  <tr>
                    <td><div style="display:flex; align-items:center; gap:0.75rem;"><span style="font-size:1.5rem;">${p.emoji}</span><div><div style="font-weight:700; font-size:0.875rem;">${p.name}</div><div style="font-size:0.75rem; color:var(--text-muted);">ID: #P${String(p.id).padStart(3,'0')}</div></div></div></td>
                    <td><span class="badge badge-green">${p.categoryLabel}</span></td>
                    <td style="font-weight:700;">${p.stockQty} kg</td>
                    <td style="font-weight:700;">₹${Object.values(p.prices)[0]}</td>
                    <td><span style="color:var(--gold);">★</span> ${p.rating}</td>
                    <td><span class="badge ${p.stockQty > 50 ? 'badge-green' : 'badge-gold'}">${p.stockQty > 50 ? 'In Stock' : 'Low Stock'}</span></td>
                    <td><div style="display:flex; gap:0.35rem;"><button class="btn btn-ghost btn-sm" onclick="showToast('Edit mode!', 'info')">Edit</button><button class="btn btn-ghost btn-sm" style="color:#e53e3e;" onclick="showToast('Product archived', 'info')">Archive</button></div></td>
                  </tr>`).join('')}
              </tbody>
            </table>
          </div>
        </div>

        <!-- Order Management -->
        <div class="table-card">
          <div class="table-header">
            <div class="table-title">Recent Orders</div>
            <div style="display:flex; gap:0.5rem; flex-wrap:wrap;">
              ${['All','Pending','Processing','Shipped','Delivered'].map((s,i) => `
                <button class="btn ${i===0?'btn-primary':'btn-ghost'} btn-sm">${s}</button>`).join('')}
            </div>
          </div>
          <div style="overflow-x:auto;">
            <table class="data-table">
              <thead><tr><th>Order ID</th><th>Customer</th><th>Product</th><th>Amount</th><th>Date</th><th>Status</th><th>Action</th></tr></thead>
              <tbody>
                ${[
                  { id:'#MM-1055', customer:'Priya Pattnaik', product:'Mixed Box (1kg)', amount:'₹375', date:'Today 9:12 AM', status:'Processing', color:'badge-blue' },
                  { id:'#MM-1054', customer:'Rajan Sharma', product:'Shiitake (500g)', amount:'₹210', date:'Today 7:30 AM', status:'Shipped', color:'badge-gold' },
                  { id:'#MM-1053', customer:'Deepa Mohanty', product:'Oyster 3×(1kg)', amount:'₹897', date:'Mar 14', status:'Delivered', color:'badge-green' },
                  { id:'#MM-1052', customer:'Suresh Kumar', product:'Button (1kg)', amount:'₹225', date:'Mar 14', status:'Delivered', color:'badge-green' },
                  { id:'#MM-1051', customer:'Meena Biswal', product:'Dried Shiitake (250g)', amount:'₹345', date:'Mar 13', status:'Pending', color:'badge-red' }
                ].map(o => `
                  <tr>
                    <td style="font-family:'DM Mono',monospace; font-size:0.875rem;">${o.id}</td>
                    <td style="font-weight:600;">${o.customer}</td>
                    <td>${o.product}</td>
                    <td style="font-weight:700;">${o.amount}</td>
                    <td style="color:var(--text-muted);">${o.date}</td>
                    <td><span class="badge ${o.color}">${o.status}</span></td>
                    <td><button class="btn btn-ghost btn-sm" onclick="navigateTo('tracking')">View</button></td>
                  </tr>`).join('')}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>`;
}

// ─── FARMER DASHBOARD ────────────────────────────────────────
function renderFarmerDashboard() {
  const main = $('#page-content');
  main.innerHTML = `
    <div class="dashboard-layout">
      <aside class="dashboard-sidebar">
        <div style="padding:0.5rem 0.5rem 1.5rem;">
          <div style="font-family:'Playfair Display',serif; font-size:1.1rem; font-weight:900; color:var(--forest);">🌾 Farmer Portal</div>
          <div style="font-size:0.75rem; color:var(--text-muted); margin-top:0.25rem;">Farm Operations</div>
        </div>
        <nav class="sidebar-menu">
          ${[
            ['🌾','Farm Overview','farmer'],['📊','Production Tracker','farmer'],['🧺','Harvest Log','farmer'],
            ['📦','Inventory','farmer'],['🔬','Disease Detection','ai-detect'],['📅','Schedule','farmer'],
            ['⬅️','Back to Admin','admin']
          ].map(([icon, label, page], i) => `
            <div class="sidebar-item ${i === 0 ? 'active' : ''}" onclick="navigateTo('${page}')">
              <span class="sidebar-icon">${icon}</span>${label}
            </div>`).join('')}
        </nav>
      </aside>
      <div class="dashboard-content">
        <div style="margin-bottom:2rem;">
          <h2 style="font-family:'Playfair Display',serif; font-size:1.5rem;">Farm Operations Dashboard</h2>
          <p style="color:var(--text-muted);">Pokatunga Farm · Bantala, Angul · Live Status</p>
        </div>

        <div class="stats-grid">
          ${[
            { label:'Today\'s Harvest', value:'42 kg', change:'+5kg vs target', emoji:'🧺', up:true },
            { label:'Active Beds', value:'180', change:'85% occupancy', emoji:'🌱', up:true },
            { label:'Ready to Harvest', value:'24 beds', change:'Next 48 hours', emoji:'⏰', up:false },
            { label:'Weekly Output', value:'210 kg', change:'+12% this week', emoji:'📈', up:true }
          ].map(s => `
            <div class="stat-card" data-emoji="${s.emoji}">
              <div class="stat-label">${s.label}</div>
              <div class="stat-value">${s.value}</div>
              <div class="stat-change ${s.up ? 'up' : ''}">${s.up ? '↑' : '⏱'} ${s.change}</div>
            </div>`).join('')}
        </div>

        <!-- Inventory Status -->
        <div class="table-card" style="margin-bottom:2rem;">
          <div class="table-header">
            <div class="table-title">🧺 Current Inventory Status</div>
            <button class="btn btn-primary btn-sm" onclick="showToast('Harvest logged!', 'success')">+ Log Harvest</button>
          </div>
          <div style="padding:1.5rem; display:flex; flex-direction:column; gap:1rem;">
            ${[
              { name:'Button Mushroom', stock:120, capacity:200, color:'var(--forest)' },
              { name:'Blue Oyster', stock:75, capacity:150, color:'#5c6bc0' },
              { name:'Golden Oyster', stock:40, capacity:100, color:'var(--gold)' },
              { name:'Wild Shiitake', stock:85, capacity:120, color:'var(--amber)' },
              { name:'Pink Oyster', stock:55, capacity:100, color:'#e91e8c' },
              { name:'Dried Shiitake', stock:200, capacity:300, color:'var(--earth)' }
            ].map(inv => {
              const pct = Math.round(inv.stock / inv.capacity * 100);
              return `
                <div>
                  <div style="display:flex; justify-content:space-between; margin-bottom:0.5rem; font-size:0.9rem;">
                    <span style="font-weight:600;">${inv.name}</span>
                    <span style="color:var(--text-muted);">${inv.stock} / ${inv.capacity} kg <strong style="color:var(--text-primary);">(${pct}%)</strong></span>
                  </div>
                  <div style="height:10px; background:var(--bg-secondary); border-radius:var(--radius-full); overflow:hidden; border:1px solid var(--border);">
                    <div style="height:100%; width:${pct}%; background:${inv.color}; border-radius:var(--radius-full); transition:width 1s ease;"></div>
                  </div>
                </div>`;
            }).join('')}
          </div>
        </div>

        <!-- Farm Activity Log -->
        <div class="table-card">
          <div class="table-header"><div class="table-title">📋 Farm Activity Log</div></div>
          <div style="overflow-x:auto;">
            <table class="data-table">
              <thead><tr><th>Time</th><th>Activity</th><th>Quantity</th><th>Performed By</th><th>Notes</th></tr></thead>
              <tbody>
                ${[
                  { time:'Today 06:30', activity:'Harvest — Button Mushroom', qty:'18 kg', by:'Ankit', notes:'Bed #12-15 harvested. Grade A quality.' },
                  { time:'Today 08:00', activity:'Substrate Prep — Oyster', qty:'50 kg batch', by:'Amulya', notes:'Wheat straw + rice bran mix ready.' },
                  { time:'Today 09:30', activity:'Watering & Misting', qty:'All beds', by:'Farm Worker', notes:'Humidity at 89%. Temp: 21°C.' },
                  { time:'Yesterday 16:00', activity:'Harvest — Shiitake', qty:'12 kg', by:'Ankit', notes:'Log beds 8-11. Some need 2 more days.' },
                  { time:'Yesterday 10:00', activity:'Inoculation', qty:'25 bags', by:'Amulya', notes:'New batch of Oyster spawn introduced.' },
                ].map(a => `
                  <tr>
                    <td style="font-size:0.8rem; color:var(--text-muted);">${a.time}</td>
                    <td style="font-weight:600;">${a.activity}</td>
                    <td style="font-family:'DM Mono',monospace;">${a.qty}</td>
                    <td>${a.by}</td>
                    <td style="font-size:0.8rem; color:var(--text-secondary);">${a.notes}</td>
                  </tr>`).join('')}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>`;
}

// ─── TRACKING PAGE ───────────────────────────────────────────
function renderTracking() {
  const main = $('#page-content');
  main.innerHTML = `
    <div class="page-hero">
      <div class="container">
        <div class="breadcrumb"><a onclick="navigateTo('home')">Home</a> <span>›</span> <span>Track Order</span></div>
        <h1 class="display-md">Track Your Order</h1>
      </div>
    </div>
    <div class="container-sm" style="padding:3rem 1.5rem 5rem;">
      <div style="display:flex; gap:0.75rem; margin-bottom:2.5rem;">
        <input class="form-input" placeholder="Enter Order ID (e.g. #MM-1055)" value="#MM-1042" style="flex:1;">
        <button class="btn btn-primary" onclick="showToast('Order found!', 'success')">Track</button>
      </div>
      
      <!-- Order Card -->
      <div style="background:var(--bg-card); border:1px solid var(--border); border-radius:var(--radius-lg); padding:2rem; margin-bottom:2rem;">
        <div style="display:flex; justify-content:space-between; flex-wrap:wrap; gap:1rem; margin-bottom:2rem;">
          <div>
            <div style="font-size:0.8rem; color:var(--text-muted); margin-bottom:0.25rem;">ORDER ID</div>
            <div style="font-family:'DM Mono',monospace; font-size:1.1rem; font-weight:700;">#MM-1042</div>
          </div>
          <div>
            <div style="font-size:0.8rem; color:var(--text-muted); margin-bottom:0.25rem;">ORDERED ON</div>
            <div style="font-weight:700;">March 10, 2025</div>
          </div>
          <div>
            <div style="font-size:0.8rem; color:var(--text-muted); margin-bottom:0.25rem;">AMOUNT</div>
            <div style="font-family:'Playfair Display',serif; font-size:1.1rem; font-weight:700; color:var(--forest);">₹490</div>
          </div>
          <div>
            <span class="badge badge-green">✓ Delivered</span>
          </div>
        </div>

        <!-- Steps -->
        <div class="tracking-steps">
          ${[
            { icon:'📋', label:'Order Placed', time:'Mar 10, 9:00 AM', done:true },
            { icon:'✅', label:'Confirmed', time:'Mar 10, 9:15 AM', done:true },
            { icon:'🌾', label:'Farm Packed', time:'Mar 10, 2:00 PM', done:true },
            { icon:'🚚', label:'Out for Delivery', time:'Mar 11, 8:30 AM', done:true },
            { icon:'🏠', label:'Delivered', time:'Mar 11, 11:45 AM', done:true, current:false }
          ].map(s => `
            <div class="tracking-step ${s.done ? 'completed' : ''} ${s.current ? 'current' : ''}">
              <div class="tracking-icon">${s.done ? '✓' : s.icon}</div>
              <div class="tracking-label">${s.label}</div>
              <div class="tracking-time">${s.time}</div>
            </div>`).join('')}
        </div>
      </div>

      <!-- Order Details -->
      <div style="background:var(--bg-card); border:1px solid var(--border); border-radius:var(--radius-lg); padding:2rem;">
        <h3 style="font-family:'Playfair Display',serif; font-size:1.15rem; margin-bottom:1.5rem;">Delivery Details</h3>
        <div style="display:grid; grid-template-columns:1fr 1fr; gap:2rem; flex-wrap:wrap;">
          <div>
            <div style="font-weight:700; margin-bottom:0.75rem;">📦 Items Ordered</div>
            <div style="display:flex; gap:0.75rem; align-items:center; padding:0.75rem; background:var(--bg-secondary); border-radius:var(--radius-md);">
              <span style="font-size:2rem;">📦</span>
              <div>
                <div style="font-weight:600;">Mixed Combo Box</div>
                <div style="font-size:0.8rem; color:var(--text-muted);">1 kg × 1</div>
              </div>
              <div style="margin-left:auto; font-weight:700;">₹490</div>
            </div>
          </div>
          <div>
            <div style="font-weight:700; margin-bottom:0.75rem;">📍 Delivery Address</div>
            <div style="font-size:0.9rem; color:var(--text-secondary); line-height:1.7; padding:0.75rem; background:var(--bg-secondary); border-radius:var(--radius-md);">
              Rajan Sharma<br>42, Tagore Nagar, Angul<br>Odisha – 759122<br>+91 94370 XXXXX
            </div>
          </div>
        </div>
      </div>
    </div>`;
}

// ─── AI DETECT PAGE ──────────────────────────────────────────
function renderAIDetect() {
  const main = $('#page-content');
  main.innerHTML = `
    <div class="page-hero">
      <div class="container">
        <div class="breadcrumb"><a onclick="navigateTo('home')">Home</a> <span>›</span> <span>AI Disease Detection</span></div>
        <h1 class="display-md">🤖 AI Mushroom Disease Detection</h1>
        <p style="color:var(--text-secondary); margin-top:0.5rem;">Upload a photo of your mushroom and our AI will identify diseases, contamination, or quality issues.</p>
      </div>
    </div>
    <div class="container-sm" style="padding:3rem 1.5rem 5rem;">
      <!-- Upload Area -->
      <div class="detection-drop" id="detect-drop" 
           ondragover="event.preventDefault(); this.classList.add('dragover')"
           ondragleave="this.classList.remove('dragover')"
           ondrop="handleDetectDrop(event)"
           onclick="$('#detect-input').click()">
        <div class="detection-icon">🔬</div>
        <div class="detection-title">Drop mushroom image here</div>
        <div class="detection-sub" style="margin-bottom:1.5rem;">or click to upload · JPG, PNG supported · Max 10MB</div>
        <button class="btn btn-primary" onclick="event.stopPropagation(); $('#detect-input').click()">📷 Upload Image</button>
        <input type="file" id="detect-input" accept="image/*" style="display:none;" onchange="analyzeImage(this)">
      </div>

      <!-- Result Placeholder -->
      <div id="detect-result" style="display:none; margin-top:2rem;">
        <div style="background:var(--bg-card); border:1px solid var(--border); border-radius:var(--radius-lg); padding:2rem;">
          <div style="display:flex; align-items:center; gap:1rem; margin-bottom:1.5rem;">
            <div style="font-size:3rem;" id="detect-result-icon">✅</div>
            <div>
              <h3 style="font-family:'Playfair Display',serif; font-size:1.25rem;" id="detect-result-title">Analysis Complete</h3>
              <p id="detect-result-sub" style="color:var(--text-muted);">AI confidence: 94%</p>
            </div>
          </div>
          <div id="detect-result-body"></div>
        </div>
      </div>

      <!-- Tips -->
      <div style="margin-top:3rem; padding:2rem; background:var(--bg-secondary); border-radius:var(--radius-lg); border:1px solid var(--border);">
        <h3 style="font-family:'Playfair Display',serif; font-size:1.1rem; margin-bottom:1.25rem;">💡 For Best Results</h3>
        <div class="grid-2">
          ${[
            ['📸', 'Good Lighting', 'Natural light or bright indoor light. Avoid shadows.'],
            ['🎯', 'Close-Up Shot', 'Fill the frame with the mushroom. Include cap & gills.'],
            ['🔄', 'Multiple Angles', 'Top, side, and underside photos improve accuracy.'],
            ['📏', 'Include Scale', 'Place a coin or ruler next to the mushroom for size reference.']
          ].map(([icon, title, desc]) => `
            <div style="display:flex; gap:0.75rem;">
              <span style="font-size:1.5rem;">${icon}</span>
              <div>
                <div style="font-weight:700; font-size:0.9rem; margin-bottom:0.25rem;">${title}</div>
                <div style="font-size:0.8rem; color:var(--text-secondary);">${desc}</div>
              </div>
            </div>`).join('')}
        </div>
      </div>
    </div>`;
}

function analyzeImage(input) {
  if (!input.files || !input.files[0]) return;
  const drop = $('#detect-drop');
  const result = $('#detect-result');
  if (drop) drop.innerHTML = `<div style="font-size:4rem; margin-bottom:1rem;">⏳</div><div class="detection-title">Analyzing image...</div><div class="detection-sub">AI is processing your upload</div>`;
  setTimeout(() => {
    if (drop) drop.innerHTML = `<div style="font-size:4rem; margin-bottom:1rem;">✅</div><div class="detection-title">Analysis Complete</div><div class="detection-sub">Click below to re-analyze</div>`;
    if (result) {
      result.style.display = 'block';
      const body = $('#detect-result-body');
      if (body) body.innerHTML = `
        <div style="display:flex; flex-direction:column; gap:0.75rem;">
          <div style="padding:0.875rem 1.25rem; background:rgba(74,124,94,0.1); border-radius:var(--radius-md); border-left:4px solid var(--fern);">
            <div style="font-weight:700; color:var(--fern);">✓ Healthy Specimen Detected</div>
            <div style="font-size:0.875rem; color:var(--text-secondary); margin-top:0.25rem;">No signs of contamination, disease, or decay detected. This mushroom appears safe and healthy.</div>
          </div>
          <div style="padding:0.875rem 1.25rem; background:var(--bg-secondary); border-radius:var(--radius-md);">
            <div style="font-weight:700; margin-bottom:0.5rem;">Detected Features</div>
            <div style="display:flex; flex-wrap:wrap; gap:0.5rem;">
              ${['Clean caps', 'No discoloration', 'Firm texture', 'No mycelial issues', 'Grade A quality'].map(f => `<span class="badge badge-green">✓ ${f}</span>`).join('')}
            </div>
          </div>
          <div style="padding:0.875rem 1.25rem; background:var(--bg-secondary); border-radius:var(--radius-md);">
            <div style="font-weight:700; margin-bottom:0.25rem;">Recommendation</div>
            <div style="font-size:0.875rem; color:var(--text-secondary);">Safe for harvest and sale. Store at 4°C with 85% humidity for maximum shelf life.</div>
          </div>
        </div>`;
    }
  }, 2500);
}

function handleDetectDrop(e) {
  e.preventDefault();
  const el = $('#detect-drop');
  if (el) el.classList.remove('dragover');
  const file = e.dataTransfer?.files?.[0];
  if (file) analyzeImage({ files: [file] });
}

// ─── NEWSLETTER ─────────────────────────────────────────────
function subscribeNewsletter(btn) {
  const input = btn.previousElementSibling;
  if (!input || !input.value.includes('@')) {
    showToast('📧 Please enter a valid email address', 'error');
    return;
  }
  showToast('🌿 Subscribed successfully! Welcome to the MycōMart family.', 'success');
  input.value = '';
}

// ─── CHATBOT ────────────────────────────────────────────────
const chatResponses = {
  'shiitake': 'Shiitake mushrooms are incredibly rich in lentinan, a beta-glucan that supports immunity. We grow ours on natural logs at our Angul farm! 🍄',
  'oyster': 'Blue, Golden, and Pink Oyster mushrooms are all available! Oyster mushrooms are great for stir-fry, soups, and curries. 🫐',
  'button': 'Button mushrooms are our most popular variety. Mild and versatile for everyday cooking. Available fresh from ₹65 for 250g! 🍄',
  'price': 'Prices start at ₹65 for Button Mushrooms (250g). We offer free shipping on orders above ₹299! 💰',
  'delivery': 'We deliver within 24 hours in Odisha! Same-day delivery in Angul district. 🚚',
  'organic': 'Yes! Our mushrooms are NPOP certified organic. Grown without pesticides at our Bantala farm. 🌿',
  'farm': 'Our farm is in Pokatunga, Bantala, Angul District, Odisha. Founded by brothers Ankit, Amulya, and Amit! 📍',
  'hello': 'Hello! Welcome to MycōMart 🍄 Ask me anything about our mushrooms, delivery, prices, or farming!',
  'hi': 'Hi there! How can I help you today? 🌿',
  'default': 'Great question! For detailed answers, please visit our FAQ page or contact us at hello@mycomart.in. Our team responds within 24 hours! 🙏'
};

function sendChatMessage() {
  const input = $('#chatbot-input');
  if (!input || !input.value.trim()) return;
  const msg = input.value.trim();
  const messages = $('#chatbot-messages');
  if (!messages) return;

  // Add user message
  const userEl = createElement('div', 'chat-msg user', msg);
  messages.appendChild(userEl);
  input.value = '';

  // Scroll to bottom
  messages.scrollTop = messages.scrollHeight;

  // Get bot response
  setTimeout(() => {
    const lower = msg.toLowerCase();
    let response = chatResponses.default;
    for (const [key, val] of Object.entries(chatResponses)) {
      if (lower.includes(key)) { response = val; break; }
    }
    const botEl = createElement('div', 'chat-msg bot', response);
    messages.appendChild(botEl);
    messages.scrollTop = messages.scrollHeight;
  }, 800);
}

function toggleChatbot() {
  const win = $('#chatbot-window');
  if (win) win.classList.toggle('active');
}

// ─── NAVBAR ─────────────────────────────────────────────────
function initNavbar() {
  window.addEventListener('scroll', () => {
    const nav = $('nav.navbar') || $('.navbar');
    if (nav) nav.classList.toggle('navbar-scrolled', window.scrollY > 20);
  });

  // Mobile hamburger
  const hamburger = $('#hamburger');
  const mobilePanel = $('#mobile-menu-panel');
  if (hamburger && mobilePanel) {
    hamburger.addEventListener('click', () => {
      mobilePanel.classList.toggle('active');
      $$('.hamburger span').forEach((s, i) => {
        if (mobilePanel.classList.contains('active')) {
          if (i === 0) s.style.transform = 'rotate(45deg) translate(5px, 5px)';
          if (i === 1) s.style.opacity = '0';
          if (i === 2) s.style.transform = 'rotate(-45deg) translate(5px, -5px)';
        } else {
          s.style.transform = '';
          s.style.opacity = '';
        }
      });
    });
  }

  // Promo close
  const promoClose = $('#promo-close');
  if (promoClose) promoClose.addEventListener('click', () => {
    const banner = $('#promo-banner');
    if (banner) banner.style.display = 'none';
  });
}

// ─── INIT ────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  initTheme();
  initNavbar();
  updateCartUI();
  updateWishlistUI();
  renderHome();

  // Close search dropdown when clicking outside
  document.addEventListener('click', (e) => {
    if (!e.target.closest('.nav-search')) {
      const dropdown = $('#search-dropdown');
      if (dropdown) dropdown.classList.remove('active');
    }
  });

  // Keyboard shortcut: Escape closes everything
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      closeCart();
      const win = $('#chatbot-window');
      if (win) win.classList.remove('active');
    }
    if (e.key === 'Enter' && document.activeElement?.id === 'chatbot-input') {
      sendChatMessage();
    }
  });

  console.log('%c🍄 MycōMart loaded! ', 'background:#1a3c2a; color:#7aad8e; padding:8px 16px; border-radius:8px; font-size:14px; font-weight:bold;');
  console.log('%cBrand names considered: MycōMart ✅, Shroomly, FungiFarm, EarthCap, SporeBox, MossGrove, HarvestHub, CanopyCo, NaturCap, MyceliaFresh', 'color:#4a7c5e;');
});
