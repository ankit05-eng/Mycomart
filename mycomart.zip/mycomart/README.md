# 🍄 MycōMart — Organic Mushroom E-Commerce Website

> Farm-Fresh Mushrooms from Pokatunga, Bantala, Angul, Odisha  
> Founded by **Ankit, Amulya & Amit Patel**

---

## 🏷️ Brand Name

After generating 10 ideas, **MycōMart** was selected:

| # | Name | Meaning |
|---|------|---------|
| ✅ 1 | **MycōMart** | Myco (fungus) + Mart (market) — short, modern, memorable |
| 2 | Shroomly | Friendly & youthful |
| 3 | FungiFarm | Direct farmstead feel |
| 4 | EarthCap | Cap (mushroom cap) + Earth |
| 5 | SporeBox | Subscription box feel |
| 6 | MossGrove | Nature-forest tranquility |
| 7 | HarvestHub | Harvest + marketplace |
| 8 | CanopyCo | Forest canopy premium |
| 9 | NaturCap | Natural + mushroom cap |
| 10 | MyceliaFresh | Mycelium + Fresh |

---

## 📁 Folder Structure

```
mycomart/
├── index.html          ← Main SPA entry point (all pages rendered here)
├── css/
│   └── main.css        ← Complete design system + all page styles
├── js/
│   └── app.js          ← All JS: data, routing, cart, wishlist, pages
└── README.md           ← This file
```

---

## 🚀 How to Run Locally

### Option 1 — Open directly in browser (simplest)
```bash
# Just double-click index.html
# Or on macOS:
open index.html

# Or on Linux:
xdg-open index.html

# Or on Windows:
start index.html
```

### Option 2 — Local server (recommended for best experience)

**Using Python (no install needed):**
```bash
cd mycomart
python3 -m http.server 3000
# Open: http://localhost:3000
```

**Using Node.js (npx):**
```bash
cd mycomart
npx serve .
# Open the URL shown in terminal
```

**Using VS Code Live Server:**
1. Install "Live Server" extension
2. Right-click `index.html` → "Open with Live Server"

---

## 📄 Pages Included

| Page | How to Access |
|------|--------------|
| 🏠 Home | Default / click logo |
| 🛍️ Shop | Nav → Shop |
| 🍄 Shop by Category | Shop → filter buttons |
| 📦 Product Detail | Click any product card |
| 🛒 Cart | Cart icon (top-right) |
| 💳 Checkout | Cart → Checkout |
| ❤️ Wishlist | Heart icon (top-right) |
| 👤 User Dashboard | Sign In → Dashboard |
| 🔧 Admin Dashboard | Mobile menu → Admin |
| 🌾 Farmer Portal | Mobile menu → Farm Portal |
| 👨‍👨‍👦 About Us | Nav → About |
| 📖 Blog | Nav → Blog |
| ❓ FAQ | Footer → FAQ |
| 📞 Contact | Nav → Contact |
| 🚚 Order Tracking | Footer → Track Order |
| 🔑 Login | Nav → Sign In |
| 📝 Register | Login → Sign Up |
| 🤖 AI Disease Detection | Admin → AI Tools |
| 💬 AI Chatbot | FAB button (bottom-right) |

---

## ✨ Features

### Shopping
- ✅ Product catalog with 8 products across 3 categories
- ✅ Live search with dropdown results
- ✅ Category & price filters
- ✅ Sort by price/rating
- ✅ Weight selector (250g / 500g / 1kg)
- ✅ Add to Cart with persistent localStorage
- ✅ Wishlist with persistent storage
- ✅ Cart sidebar with quantity controls
- ✅ Promo code system (try `FRESH20` or `MYCOMART10`)

### UX / Design
- ✅ Dark mode toggle (persists across sessions)
- ✅ Fully responsive (mobile + tablet + desktop)
- ✅ Smooth page transitions & scroll-reveal animations
- ✅ Sticky navbar with scroll shadow
- ✅ Toast notifications
- ✅ Page loader animation

### Dashboards
- ✅ User Dashboard (orders, addresses, wishlist)
- ✅ Admin Dashboard (product/order/customer management)
- ✅ Farmer Dashboard (harvest tracking, inventory, activity log)

### AI Features
- ✅ AI Chatbot (MycōBot) with mushroom Q&A
- ✅ Disease Detection UI (drag & drop image upload with simulated AI result)
- ✅ Product recommendations on detail pages

---

## 🛒 Sample Products

| Product | Category | Price (250g) |
|---------|----------|-------------|
| Creamy White Button Mushroom | Button | ₹65 |
| Blue Oyster Mushroom | Oyster | ₹85 |
| Golden Oyster Mushroom | Oyster | ₹95 |
| Wild Shiitake Mushroom | Shiitake | ₹110 |
| Pink Oyster Mushroom | Oyster | ₹90 |
| Dried Shiitake Pack | Shiitake | ₹150/100g |
| Button Mushroom Organic | Button | ₹80 |
| Mixed Combo Box | Combo | ₹199/500g |

---

## 🎨 Design System

- **Font Display:** Playfair Display (serif)
- **Font Body:** DM Sans
- **Font Mono:** DM Mono
- **Primary Color:** Forest Green `#1a3c2a`
- **Accent:** Gold `#e8a830` / Amber `#d4782a`
- **Background:** Warm ivory `#faf7f2`
- **Style:** Organic / Nature-inspired / Premium

---

## 📍 Farm Location

**Pokatunga, Bantala, Angul District, Odisha, India**

Founded by:
- **Ankit Patel** — Farm Operations
- **Amulya Patel** — Quality & R&D  
- **Amit Patel** — Sales & Marketing

---

## 🔧 Tech Stack

- **Pure HTML5** — Single-page app with JS routing
- **CSS3** — Custom design system, CSS variables, animations
- **Vanilla JavaScript** — No dependencies, no frameworks
- **Google Fonts** — Playfair Display + DM Sans

No build step. No npm install. Just open and run. 🚀
